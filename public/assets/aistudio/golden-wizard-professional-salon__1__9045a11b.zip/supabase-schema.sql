-- ============================================================================
-- GOLDEN WIZARD PROFESSIONAL SALON — PRODUCTION SUPABASE POSTGRESQL SCHEMA
-- Database: PostgreSQL 14+ / Supabase
-- Features:
-- - Questions & Answers table with strict RLS (Anonymous public read-only for answered,
--   anonymous write with status=pending, owner full management)
-- - Appointment Bookings table with owner management
-- - Website Settings table
-- - Owner authorization profile checks
-- ============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
DO $$ BEGIN
    CREATE TYPE question_status AS ENUM ('pending', 'answered');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'completed', 'cancelled');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. CUSTOMER QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    question TEXT NOT NULL CHECK (char_length(trim(question)) >= 10 AND char_length(question) <= 500),
    asker_name TEXT CHECK (char_length(asker_name) <= 100),
    answer TEXT CHECK (answer IS NULL OR (char_length(trim(answer)) >= 5 AND char_length(answer) <= 2000)),
    status question_status NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    answered_at TIMESTAMPTZ
);

-- Indexes for lightning-fast queries
CREATE INDEX IF NOT EXISTS idx_questions_status ON public.questions(status);
CREATE INDEX IF NOT EXISTS idx_questions_answered_at ON public.questions(answered_at DESC) WHERE status = 'answered';
CREATE INDEX IF NOT EXISTS idx_questions_created_at ON public.questions(created_at DESC);

-- 4. APPOINTMENT BOOKING ENQUIRIES TABLE
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_name TEXT NOT NULL CHECK (char_length(trim(customer_name)) >= 2 AND char_length(customer_name) <= 100),
    customer_phone TEXT NOT NULL CHECK (char_length(trim(customer_phone)) >= 10 AND char_length(customer_phone) <= 20),
    service_name TEXT NOT NULL CHECK (char_length(service_name) >= 2),
    preferred_date DATE NOT NULL,
    preferred_time TEXT NOT NULL,
    notes TEXT CHECK (notes IS NULL OR char_length(notes) <= 500),
    status booking_status NOT NULL DEFAULT 'pending',
    assigned_staff TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON public.bookings(preferred_date DESC);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON public.bookings(created_at DESC);

-- 5. WEBSITE SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Seed initial default settings if empty
INSERT INTO public.settings (key, value)
VALUES (
    'general',
    jsonb_build_object(
        'announcement', '✨ Welcome to Golden Wizard Professional Salon. Experience world-class hair & beauty care in Gandi Maisamma.',
        'showAnnouncement', true,
        'brandColor', '#C6A15B'
    )
)
ON CONFLICT (key) DO NOTHING;

-- 6. SALON OWNERS AUTHORIZATION TABLE
CREATE TABLE IF NOT EXISTS public.owners (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Helper function to check if current user is an authorized owner
CREATE OR REPLACE FUNCTION public.is_salon_owner()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.owners
    WHERE id = auth.uid()
  );
$$;

-- ============================================================================
-- 7. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS on all tables
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.owners ENABLE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------------------
-- QUESTIONS TABLE POLICIES
-- ----------------------------------------------------------------------------
-- Anonymous visitors can READ ONLY answered questions
CREATE POLICY "Public visitors can read published answered questions"
ON public.questions
FOR SELECT
TO public
USING (status = 'answered');

-- Anonymous visitors can INSERT questions with status 'pending' and NULL answer
CREATE POLICY "Public visitors can submit new questions as pending"
ON public.questions
FOR INSERT
TO public
WITH CHECK (
    status = 'pending' AND
    answer IS NULL AND
    answered_at IS NULL
);

-- Authorized salon owner can read all questions (pending and answered)
CREATE POLICY "Owner can read all questions"
ON public.questions
FOR SELECT
TO authenticated
USING (public.is_salon_owner());

-- Authorized salon owner can update questions (write answer, publish, unpublish)
CREATE POLICY "Owner can update questions and publish answers"
ON public.questions
FOR UPDATE
TO authenticated
USING (public.is_salon_owner())
WITH CHECK (public.is_salon_owner());

-- Authorized salon owner can delete questions
CREATE POLICY "Owner can delete questions"
ON public.questions
FOR DELETE
TO authenticated
USING (public.is_salon_owner());

-- ----------------------------------------------------------------------------
-- BOOKINGS TABLE POLICIES
-- ----------------------------------------------------------------------------
-- Public visitors can submit appointment bookings (status must be 'pending')
CREATE POLICY "Public visitors can submit appointment requests"
ON public.bookings
FOR INSERT
TO public
WITH CHECK (status = 'pending');

-- Only authorized salon owner can view all bookings
CREATE POLICY "Owner can view all appointment bookings"
ON public.bookings
FOR SELECT
TO authenticated
USING (public.is_salon_owner());

-- Only authorized salon owner can update booking status
CREATE POLICY "Owner can update appointment bookings"
ON public.bookings
FOR UPDATE
TO authenticated
USING (public.is_salon_owner())
WITH CHECK (public.is_salon_owner());

-- Only authorized salon owner can delete bookings
CREATE POLICY "Owner can delete appointment bookings"
ON public.bookings
FOR DELETE
TO authenticated
USING (public.is_salon_owner());

-- ----------------------------------------------------------------------------
-- SETTINGS TABLE POLICIES
-- ----------------------------------------------------------------------------
-- Public visitors can read settings
CREATE POLICY "Public visitors can read general settings"
ON public.settings
FOR SELECT
TO public
USING (true);

-- Only authorized salon owner can modify settings
CREATE POLICY "Owner can update settings"
ON public.settings
FOR ALL
TO authenticated
USING (public.is_salon_owner())
WITH CHECK (public.is_salon_owner());
