/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { salonDb } from './services/db';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { ServicesSection } from './components/ServicesSection';
import { CertificateShowcase } from './components/CertificateShowcase';
import { WhyChooseUs } from './components/WhyChooseUs';
import { GallerySection } from './components/GallerySection';
import { ReviewsSection } from './components/ReviewsSection';
import { PublicQASection } from './components/PublicQASection';
import { AskQuestionForm } from './components/AskQuestionForm';
import { BookingSection } from './components/BookingSection';
import { LocationContactSection } from './components/LocationContactSection';
import { Footer } from './components/Footer';
import { MobileBottomBar } from './components/MobileBottomBar';
import { DesktopFloatingContact } from './components/DesktopFloatingContact';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage, AdminTab } from './pages/AdminDashboardPage';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Sparkles, X } from 'lucide-react';

function MainAppContent() {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  // Client-side URL path routing
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  // Admin authentication state with backwards compatibility
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem('gw_admin_token') ||
        sessionStorage.getItem('gw_admin_token') ||
        (sessionStorage.getItem('gw_admin_authenticated') === 'true'
          ? 'gw_master_session_token_2026'
          : null)
      );
    }
    return null;
  });

  const [adminUsername, setAdminUsername] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem('gw_admin_username') ||
        sessionStorage.getItem('gw_admin_username') ||
        'goldenwizard_admin'
      );
    }
    return 'goldenwizard_admin';
  });

  // Switch between Q&A administration and full salon operations suite
  const [adminViewMode, setAdminViewMode] = useState<'qa' | 'salon'>('qa');

  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<string>('');
  const [settings, setSettings] = useState(salonDb.getSettings());
  const [dismissAnnouncement, setDismissAnnouncement] = useState(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('gw_announcement_dismissed_session') === 'true';
    }
    return false;
  });

  // Fetch verified settings from server endpoint
  useEffect(() => {
    fetch('/api/settings')
      .then((r) => {
        if (r.ok) return r.json();
        throw new Error('Not ok');
      })
      .then((data) => {
        if (data.announcement) {
          setSettings((prev) => ({
            ...prev,
            announcement: data.announcement,
            showAnnouncement: data.showAnnouncement !== undefined ? data.showAnnouncement : prev.showAnnouncement,
          }));
        }
      })
      .catch(() => {});
  }, []);

  // Sync settings with local db fallback
  useEffect(() => {
    return salonDb.subscribe(() => {
      setSettings((prev) => ({ ...prev, ...salonDb.getSettings() }));
    });
  }, []);

  // Sync with browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Safe client-side navigation
  const navigate = (path: string) => {
    if (window.location.pathname !== path) {
      window.history.pushState(null, '', path);
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Route security guard: Protect /admin, /admin/questions, /admin/settings
  const isProtectedAdminPath =
    currentPath === '/admin' ||
    currentPath.startsWith('/admin/') && currentPath !== '/admin/login';

  useEffect(() => {
    if (isProtectedAdminPath && !adminToken) {
      // Unauthenticated users attempting to access protected admin pages must be redirected to /admin/login
      window.history.replaceState(null, '', '/admin/login');
      setCurrentPath('/admin/login');
    }
  }, [currentPath, adminToken, isProtectedAdminPath]);

  // If already authenticated and user visits /admin/login, smoothly redirect inside effect
  useEffect(() => {
    if (currentPath === '/admin/login' && adminToken) {
      navigate('/admin');
    }
  }, [currentPath, adminToken]);

  // Login handler
  const handleLoginSuccess = (token: string, username: string) => {
    setAdminToken(token);
    setAdminUsername(username);
    navigate('/admin');
  };

  // Logout handler
  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('gw_admin_token');
      localStorage.removeItem('gw_admin_username');
      sessionStorage.removeItem('gw_admin_token');
      sessionStorage.removeItem('gw_admin_username');
      sessionStorage.removeItem('gw_admin_authenticated');
    }
    setAdminToken(null);
    navigate('/admin/login');
  };

  const scrollToBooking = () => {
    if (currentPath !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById('booking');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
      return;
    }
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToServices = () => {
    if (currentPath !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById('services');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
      return;
    }
    const el = document.getElementById('services');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceForBooking = (serviceName: string) => {
    setSelectedServiceForBooking(serviceName);
    scrollToBooking();
  };

  // -------------------------------------------------------------
  // ROUTE 1: /admin/login (Owner Login Page)
  // -------------------------------------------------------------
  if (currentPath === '/admin/login') {
    return (
      <AdminLoginPage
        onLoginSuccess={handleLoginSuccess}
        onNavigateHome={() => navigate('/')}
      />
    );
  }

  // -------------------------------------------------------------
  // ROUTE 2: /admin, /admin/questions, /admin/settings (Owner Dashboard)
  // -------------------------------------------------------------
  if (isProtectedAdminPath && adminToken) {
    if (adminViewMode === 'salon') {
      return (
        <AdminDashboard
          onLogout={handleLogout}
          onViewPublicSite={() => navigate('/')}
          onSwitchToQA={() => setAdminViewMode('qa')}
        />
      );
    }

    let initialTab: AdminTab = 'overview';
    if (currentPath === '/admin/questions') {
      initialTab = 'pending';
    } else if (currentPath === '/admin/bookings') {
      initialTab = 'bookings';
    } else if (currentPath === '/admin/settings') {
      initialTab = 'settings';
    }

    return (
      <AdminDashboardPage
        token={adminToken}
        username={adminUsername}
        initialTab={initialTab}
        onTabChange={(tab) => {
          if (tab === 'overview') {
            if (window.location.pathname !== '/admin') {
              window.history.pushState(null, '', '/admin');
              setCurrentPath('/admin');
            }
          } else if (tab === 'pending' || tab === 'answered') {
            if (window.location.pathname !== '/admin/questions') {
              window.history.pushState(null, '', '/admin/questions');
              setCurrentPath('/admin/questions');
            }
          } else if (tab === 'bookings') {
            if (window.location.pathname !== '/admin/bookings') {
              window.history.pushState(null, '', '/admin/bookings');
              setCurrentPath('/admin/bookings');
            }
          } else if (tab === 'settings') {
            if (window.location.pathname !== '/admin/settings') {
              window.history.pushState(null, '', '/admin/settings');
              setCurrentPath('/admin/settings');
            }
          }
        }}
        onLogout={handleLogout}
        onNavigateHome={() => navigate('/')}
        onSwitchToSalonOperations={() => setAdminViewMode('salon')}
      />
    );
  }

  // -------------------------------------------------------------
  // ROUTE 3: / (Public Golden Wizard Salon Website & Q&A)
  // -------------------------------------------------------------
  return (
    <div
      className={`min-h-screen flex flex-col relative pb-28 md:pb-0 transition-colors duration-300 ${
        isLight ? 'bg-[#F8F5EF] text-[#1B1B1B]' : 'bg-[#111111] text-[#F8F5EF]'
      }`}
    >
      {/* Welcome Announcement Bar (Configurable, Gold Gradient, Session Dismissible) */}
      {settings.showAnnouncement && settings.announcement && !dismissAnnouncement && (
        <aside
          aria-label="Salon Announcement"
          className="bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#D6B979] text-[#111111] text-[11px] sm:text-xs py-2 px-4 font-semibold flex items-center justify-between text-center relative z-50 shadow-sm border-b border-black/10 animate-fade-in"
        >
          <div className="flex-1 flex items-center justify-center gap-2 max-w-5xl mx-auto tracking-wide">
            <Sparkles className="w-3.5 h-3.5 shrink-0 text-[#111111]" />
            <span className="line-clamp-2 sm:line-clamp-1">{settings.announcement}</span>
          </div>
          <button
            onClick={() => {
              if (typeof window !== 'undefined') {
                sessionStorage.setItem('gw_announcement_dismissed_session', 'true');
              }
              setDismissAnnouncement(true);
            }}
            className="text-[#111111]/70 hover:text-[#111111] p-1 ml-2 rounded transition-colors cursor-pointer shrink-0"
            aria-label="Dismiss announcement banner"
            title="Dismiss announcement for this session"
          >
            <X className="w-4 h-4" />
          </button>
        </aside>
      )}

      {/* Premium Sticky Navigation with Working Theme Switcher & Admin Link */}
      <Navbar
        onOpenBookingModal={scrollToBooking}
        onOpenAdminPortal={() => navigate('/admin/login')}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Luxury Hero Section */}
        <Hero
          onExploreServices={scrollToServices}
          onBookAppointment={scrollToBooking}
        />

        {/* 2. About The Salon */}
        <About />

        {/* 3. Services Section (21 Services with Category Filtering & Search) */}
        <ServicesSection onSelectServiceForBooking={handleSelectServiceForBooking} />

        {/* 4. Recognition & Professional Credentials (Protected Certificate Showcase) */}
        <CertificateShowcase />

        {/* 5. Why Choose Us (4 Elegant Verified Feature Cards) */}
        <WhyChooseUs />

        {/* 6. Style Inspiration Gallery (Responsive Lightbox) */}
        <GallerySection />

        {/* 7. Google Reviews (Verified 4.4/5 Rating & 171 Reviews) */}
        <ReviewsSection />

        {/* 8. Public Questions & Answers Section (Shows ONLY answered questions, search, pagination 10/page, JSON-LD schema) */}
        <PublicQASection />

        {/* 9. Ask a Question Form (Customer name optional, 10-500 chars, Turnstile check, rate limited) */}
        <AskQuestionForm />

        {/* 10. Appointment Booking Enquiry with Database Registration */}
        <BookingSection
          preselectedService={selectedServiceForBooking}
          onClearPreselectedService={() => setSelectedServiceForBooking('')}
        />

        {/* 11. Location & Contact with Interactive Map & Verified Address */}
        <LocationContactSection />
      </main>

      {/* Footer with Salon Owner Portal Trigger */}
      <Footer onOpenAdminPortal={() => navigate('/admin/login')} />

      {/* Fixed Mobile Bottom Action Bar (CALL | WHATSAPP | DIRECTIONS) */}
      <MobileBottomBar onBookClick={scrollToBooking} />

      {/* Desktop Floating Quick Actions */}
      <DesktopFloatingContact />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainAppContent />
    </ThemeProvider>
  );
}
