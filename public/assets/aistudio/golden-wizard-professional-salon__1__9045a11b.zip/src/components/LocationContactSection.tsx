import React from 'react';
import { SALON_INFO } from '../data/salonData';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { MapPin, Phone, MessageCircle, Navigation, Clock, CheckCircle2, ExternalLink } from 'lucide-react';

export const LocationContactSection: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  return (
    <section id="contact" className={`py-20 md:py-28 relative border-t transition-colors ${
      isLight ? 'bg-[#F8F5EF] border-black/5' : 'bg-[#151515] border-white/5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Location & Hours
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Visit Our <span className="gold-gradient-text italic font-normal">Salon</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'}`}>
            Conveniently situated right at Gandi Maisamma X Road, directly opposite the Indian Oil Petrol Pump. Easy to locate with dedicated service and parking access.
          </p>
        </div>

        {/* Content Grid: Location Card (Left) & Embedded Map (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Location & Details Card */}
          <div className={`lg:col-span-5 border rounded-sm p-6 sm:p-8 flex flex-col justify-between shadow-2xl transition-all ${
            isLight
              ? 'bg-[#FFFFFF] border-[#C6A15B]/30 shadow-black/5'
              : 'bg-[#1A1A1A] border-[#C6A15B]/30 shadow-black/50'
          }`}>
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-semibold text-emerald-500 tracking-wider uppercase">
                  Open Today Until 9:00 PM
                </span>
              </div>

              <h3 className={`font-serif-elegant text-2xl sm:text-3xl font-bold mb-2 ${
                isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
              }`}>
                {SALON_INFO.name}
              </h3>
              <p className="text-xs text-[#C6A15B] font-semibold tracking-wider uppercase mb-6">
                {SALON_INFO.category}
              </p>

              {/* Address item */}
              <div className="space-y-5 text-sm">
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-sm bg-[#111111] border border-[#C6A15B]/40 flex items-center justify-center shrink-0 mt-0.5 text-[#C6A15B]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider opacity-50 mb-1">
                      Salon Address
                    </h4>
                    <p className={`font-medium leading-relaxed ${isLight ? 'text-black' : 'text-white'}`}>
                      {SALON_INFO.address.line1},
                    </p>
                    <p className="text-[#C6A15B] font-semibold leading-relaxed">
                      {SALON_INFO.address.landmark},
                    </p>
                    <p className="opacity-80 leading-relaxed text-xs">
                      {SALON_INFO.address.area}, {SALON_INFO.address.city}, {SALON_INFO.address.state} {SALON_INFO.address.pincode}
                    </p>
                  </div>
                </div>

                {/* Phone Item */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-sm bg-[#111111] border border-[#C6A15B]/40 flex items-center justify-center shrink-0 mt-0.5 text-[#C6A15B]">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider opacity-50 mb-1">
                      Direct Telephone
                    </h4>
                    <a
                      href={`tel:${SALON_INFO.phoneRaw}`}
                      className="font-bold text-base hover:text-[#C6A15B] transition-colors"
                    >
                      {SALON_INFO.phoneDisplay}
                    </a>
                    <p className="text-xs opacity-50 mt-0.5">
                      Direct line for appointments & queries
                    </p>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-sm bg-[#111111] border border-[#C6A15B]/40 flex items-center justify-center shrink-0 mt-0.5 text-[#C6A15B]">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider opacity-50 mb-1">
                      Operating Hours
                    </h4>
                    <p className={`font-medium ${isLight ? 'text-black' : 'text-white'}`}>
                      Monday – Sunday: 9:00 AM – 9:00 PM
                    </p>
                    <p className="text-xs text-emerald-500 mt-0.5 flex items-center gap-1 font-medium">
                      <CheckCircle2 className="w-3 h-3" />
                      Open all 7 days of the week
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Action Buttons */}
            <div className="mt-8 pt-6 border-t border-black/10 dark:border-white/10 space-y-3">
              <a
                href={SALON_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 bg-[#C6A15B] hover:bg-[#D6B979] text-[#111111] font-semibold text-xs tracking-wider uppercase rounded-sm flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Navigation className="w-4 h-4" />
                <span>Get Directions (Google Maps)</span>
              </a>

              <div className="grid grid-cols-2 gap-2.5">
                <a
                  href={`tel:${SALON_INFO.phoneRaw}`}
                  className="py-2.5 px-3 bg-[#1F1F1F] hover:bg-[#2a2a2a] border border-white/10 text-white font-medium text-xs rounded-sm flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Call Now</span>
                </a>
                <a
                  href={`https://wa.me/${SALON_INFO.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-3 bg-[#1F1F1F] hover:bg-[#2a2a2a] border border-[#C6A15B]/35 text-[#D6B979] font-medium text-xs rounded-sm flex items-center justify-center gap-1.5 transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>
          </div>

          {/* Interactive Google Maps Frame */}
          <div className="lg:col-span-7 bg-[#1A1A1A] border border-[#C6A15B]/30 rounded-sm overflow-hidden flex flex-col min-h-[380px] lg:min-h-full shadow-2xl relative">
            <div className="p-3 bg-[#131313] border-b border-white/10 flex items-center justify-between text-xs text-[#EAE2D5]">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#C6A15B]" />
                <span className="font-medium">Google Maps Navigation</span>
              </span>
              <a
                href={SALON_INFO.googleMapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#C6A15B] hover:underline flex items-center gap-1"
              >
                <span>Open in Full App</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="flex-1 w-full relative min-h-[350px]">
              <iframe
                title="Golden Wizard Professional Salon Map"
                src="https://maps.google.com/maps?q=4,+Gandi+Maisamma+X+Rd,+Opposite+Indian+Oil+Petrol+Pump,+Gandi+Maisamma,+Hyderabad,+Telangana+500043&t=&z=16&ie=UTF8&iwloc=&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '360px' }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full filter invert-[0.9] hue-rotate-180 contrast-[1.1] grayscale-[0.2]"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
