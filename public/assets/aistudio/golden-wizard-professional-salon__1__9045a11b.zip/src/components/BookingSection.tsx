import React, { useState, useEffect } from 'react';
import { salonDb } from '../services/db';
import { SALON_INFO } from '../data/salonData';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Calendar, Clock, User, Phone, MessageSquare, AlertCircle, CheckCircle, Sparkles, Send, ShieldAlert } from 'lucide-react';

interface BookingSectionProps {
  preselectedService?: string;
  onClearPreselectedService?: () => void;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  preselectedService,
  onClearPreselectedService,
}) => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);
  const [hasConflictNotice, setHasConflictNotice] = useState(false);

  // Set today's date as min
  const todayString = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (preselectedService) {
      setService(preselectedService);
    }
  }, [preselectedService]);

  const timeSlots = [
    '09:30 AM',
    '10:30 AM',
    '11:30 AM',
    '12:30 PM',
    '02:00 PM',
    '03:30 PM',
    '04:30 PM',
    '05:30 PM',
    '06:30 PM',
    '07:30 PM',
    '08:00 PM',
  ];

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [whatsappShareUrl, setWhatsappShareUrl] = useState<string | null>(null);

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) {
      newErrors.name = 'Please provide your full name.';
    }

    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (!phone.trim()) {
      newErrors.phone = 'Please provide your mobile number.';
    } else if (cleanPhone.length < 10) {
      newErrors.phone = 'Please enter a valid 10-digit mobile number.';
    }

    if (!service) {
      newErrors.service = 'Please select a salon service.';
    }

    if (!date) {
      newErrors.date = 'Please pick a preferred date.';
    }

    if (!time) {
      newErrors.time = 'Please select a preferred time.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    const cleanMobile = phone.replace(/[^0-9]/g, '');

    try {
      // 1. Post to backend REST API
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_name: name.trim(),
          customer_phone: cleanMobile,
          service_name: service,
          preferred_date: date,
          preferred_time: time,
          notes: notes.trim() || null,
        }),
      });

      const serverData = await response.json().catch(() => ({}));

      // 2. Also register in local salonDb
      const result = salonDb.createAppointment({
        customerName: name.trim(),
        mobile: cleanMobile,
        service,
        date,
        timeSlot: time,
        notes: notes.trim(),
      });

      if (result.conflict) {
        setHasConflictNotice(true);
      } else {
        setHasConflictNotice(false);
      }

      const aptId = serverData.booking?.id || result.appointment?.id || 'GW-APT';
      setSubmissionSuccess(aptId);

      // WhatsApp direct message URL for optional user tap
      const message =
        `*APPOINTMENT ENQUIRY [${aptId}] - GOLDEN WIZARD SALON*\n\n` +
        `*Client Name:* ${name.trim()}\n` +
        `*Phone:* ${cleanMobile}\n` +
        `*Service Requested:* ${service}\n` +
        `*Preferred Date:* ${date}\n` +
        `*Preferred Time Slot:* ${time}\n` +
        (notes.trim() ? `*Notes/Requests:* ${notes.trim()}\n` : '') +
        `\n_Submitted via Golden Wizard website form._`;

      const encodedMessage = encodeURIComponent(message);
      setWhatsappShareUrl(`https://wa.me/${SALON_INFO.whatsappNumber}?text=${encodedMessage}`);
    } catch (err) {
      console.error('Booking submission error', err);
      // Fallback local save
      salonDb.createAppointment({
        customerName: name.trim(),
        mobile: cleanMobile,
        service,
        date,
        timeSlot: time,
        notes: notes.trim(),
      });
      setSubmissionSuccess('GW-REQ');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="booking" className={`py-20 md:py-28 relative overflow-hidden transition-colors ${
      isLight ? 'bg-[#F8F5EF]' : 'bg-[#111111]'
    }`}>
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl h-80 bg-[#C6A15B]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Schedule Your Visit
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Let's Create Your <span className="gold-gradient-text italic font-normal">Perfect Look</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'}`}>
            Fill out your appointment details below. We'll record your booking enquiry in our system and instantly formulate your request on WhatsApp to confirm slot availability.
          </p>
        </div>

        {/* Booking Form Card */}
        <div className={`border rounded-sm p-6 sm:p-10 shadow-2xl relative transition-all ${
          isLight
            ? 'bg-[#FFFFFF] border-[#C6A15B]/30 shadow-[#C6A15B]/10'
            : 'bg-[#181818] border-[#C6A15B]/30'
        }`}>
          {/* Important Notice Banner */}
          <div className={`mb-8 p-4 rounded-sm border-l-4 border-[#C6A15B] flex items-start gap-3 ${
            isLight ? 'bg-[#F5F1E8]' : 'bg-[#121212]'
          }`}>
            <AlertCircle className="w-5 h-5 text-[#C6A15B] shrink-0 mt-0.5" />
            <div className={`text-xs leading-relaxed ${isLight ? 'text-[#3D3A34]' : 'text-[#EAE2D5]/90'}`}>
              <strong className="font-semibold">WhatsApp-Based Enquiry:</strong> Submitting this form creates a registered appointment request with Golden Wizard Professional Salon. Our salon coordinator will review stylist availability and confirm your booking.
            </div>
          </div>

          {hasConflictNotice && (
            <div className="mb-6 p-4 bg-amber-950/40 border border-amber-500/50 rounded-sm flex items-center gap-2.5 text-xs text-amber-200">
              <ShieldAlert className="w-5 h-5 shrink-0 text-amber-400" />
              <span>Note: This time slot currently has high booking demand. Our team will verify if an extra stylist chair is available or propose the closest adjacent slot on WhatsApp.</span>
            </div>
          )}

          {submissionSuccess && (
            <div className="mb-6 p-5 bg-emerald-950/40 border border-emerald-500/50 rounded-sm text-xs sm:text-sm text-emerald-200">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-emerald-300 text-sm">
                      Appointment Enquiry Received! (Ref: <span className="font-mono">{submissionSuccess}</span>)
                    </h4>
                    <p className="text-xs text-emerald-200/80 mt-1 leading-relaxed">
                      Thank you! Your appointment request has been recorded in our system. Our team will verify stylist chair availability and contact you via call/SMS to confirm your booking.
                    </p>
                    {whatsappShareUrl && (
                      <div className="mt-3">
                        <a
                          href={whatsappShareUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#25D366] text-[#111111] font-semibold text-xs rounded-sm hover:brightness-110 transition-all shadow-sm"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Fast-Track Confirmation on WhatsApp</span>
                        </a>
                      </div>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSubmissionSuccess(null)}
                  className="text-emerald-400/70 hover:text-white text-xs underline cursor-pointer shrink-0"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Full Name */}
              <div>
                <label className={`block text-xs font-semibold tracking-wider uppercase mb-2 ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Customer Name <span className="text-[#C6A15B]">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors({ ...errors, name: '' });
                    }}
                    placeholder="e.g. Rahul Sharma"
                    className={`w-full pl-10 pr-4 py-3 border ${
                      errors.name ? 'border-rose-500/80' : isLight ? 'border-black/10 focus:border-[#C6A15B]' : 'border-white/10 focus:border-[#C6A15B]'
                    } rounded-sm text-sm focus:outline-none transition-colors ${
                      isLight ? 'bg-[#F9F7F2] text-black placeholder-black/40' : 'bg-[#121212] text-white placeholder-white/30'
                    }`}
                  />
                </div>
                {errors.name && (
                  <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.name}
                  </p>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <label className={`block text-xs font-semibold tracking-wider uppercase mb-2 ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Phone Number <span className="text-[#C6A15B]">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (errors.phone) setErrors({ ...errors, phone: '' });
                    }}
                    placeholder="e.g. 98765 43210"
                    className={`w-full pl-10 pr-4 py-3 border ${
                      errors.phone ? 'border-rose-500/80' : isLight ? 'border-black/10 focus:border-[#C6A15B]' : 'border-white/10 focus:border-[#C6A15B]'
                    } rounded-sm text-sm focus:outline-none transition-colors ${
                      isLight ? 'bg-[#F9F7F2] text-black placeholder-black/40' : 'bg-[#121212] text-white placeholder-white/30'
                    }`}
                  />
                </div>
                {errors.phone && (
                  <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.phone}
                  </p>
                )}
              </div>
            </div>

            {/* Select Service */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className={`block text-xs font-semibold tracking-wider uppercase ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Select Service <span className="text-[#C6A15B]">*</span>
                </label>
                {service && onClearPreselectedService && (
                  <button
                    type="button"
                    onClick={() => {
                      setService('');
                      onClearPreselectedService();
                    }}
                    className="text-[11px] text-[#C6A15B] hover:underline"
                  >
                    Clear selection
                  </button>
                )}
              </div>
              <div className="relative">
                <Sparkles className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={service}
                  onChange={(e) => {
                    setService(e.target.value);
                    if (errors.service) setErrors({ ...errors, service: '' });
                  }}
                  className={`w-full pl-10 pr-8 py-3 border ${
                    errors.service ? 'border-rose-500/80' : isLight ? 'border-black/10 focus:border-[#C6A15B]' : 'border-white/10 focus:border-[#C6A15B]'
                  } rounded-sm text-sm focus:outline-none transition-colors appearance-none cursor-pointer ${
                    isLight ? 'bg-[#F9F7F2] text-black' : 'bg-[#121212] text-white'
                  }`}
                >
                  <option value="" disabled className="text-white/40">
                    -- Choose from our 21 salon services --
                  </option>
                  <optgroup label="Hair Services">
                    <option value="Haircut">Haircut</option>
                    <option value="Hairstyling">Hairstyling</option>
                    <option value="Blow Dry">Blow Dry</option>
                    <option value="Hair Straightening">Hair Straightening</option>
                    <option value="Curly Hair Styling">Curly Hair Styling</option>
                    <option value="Braiding">Braiding</option>
                    <option value="Children's Haircuts">Children's Haircuts</option>
                    <option value="Shampoo and Conditioning">Shampoo and Conditioning</option>
                    <option value="Perms">Perms</option>
                  </optgroup>
                  <optgroup label="Colouring & Treatments">
                    <option value="Hair Colouring">Hair Colouring</option>
                    <option value="Hair Highlighting">Hair Highlighting</option>
                    <option value="Balayage">Balayage</option>
                    <option value="Keratin Treatments">Keratin Treatments</option>
                    <option value="Hair Treatments">Hair Treatments</option>
                    <option value="Hair Regrowth Services">Hair Regrowth Services</option>
                  </optgroup>
                  <optgroup label="Bridal & Makeup">
                    <option value="Bridal Hair">Bridal Hair</option>
                    <option value="Bridal Services">Bridal Services</option>
                    <option value="Makeup Services">Makeup Services</option>
                  </optgroup>
                  <optgroup label="Beauty & Grooming">
                    <option value="Shaving & Beard Grooming">Shaving & Beard Grooming</option>
                    <option value="De-tan and Facial">De-tan and Facial</option>
                    <option value="Manicure and Pedicure">Manicure and Pedicure</option>
                  </optgroup>
                </select>
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-xs text-white/50">
                  ▼
                </div>
              </div>
              {errors.service && (
                <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {errors.service}
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Preferred Date */}
              <div>
                <label className={`block text-xs font-semibold tracking-wider uppercase mb-2 ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Preferred Date <span className="text-[#C6A15B]">*</span>
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="date"
                    min={todayString}
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      if (errors.date) setErrors({ ...errors, date: '' });
                    }}
                    className={`w-full pl-10 pr-4 py-3 border ${
                      errors.date ? 'border-rose-500/80' : isLight ? 'border-black/10 focus:border-[#C6A15B]' : 'border-white/10 focus:border-[#C6A15B]'
                    } rounded-sm text-sm focus:outline-none transition-colors cursor-pointer ${
                      isLight ? 'bg-[#F9F7F2] text-black' : 'bg-[#121212] text-white'
                    }`}
                  />
                </div>
                {errors.date && (
                  <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.date}
                  </p>
                )}
              </div>

              {/* Preferred Time */}
              <div>
                <label className={`block text-xs font-semibold tracking-wider uppercase mb-2 ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Preferred Time Slot <span className="text-[#C6A15B]">*</span>
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <select
                    value={time}
                    onChange={(e) => {
                      setTime(e.target.value);
                      if (errors.time) setErrors({ ...errors, time: '' });
                    }}
                    className={`w-full pl-10 pr-8 py-3 border ${
                      errors.time ? 'border-rose-500/80' : isLight ? 'border-black/10 focus:border-[#C6A15B]' : 'border-white/10 focus:border-[#C6A15B]'
                    } rounded-sm text-sm focus:outline-none transition-colors appearance-none cursor-pointer ${
                      isLight ? 'bg-[#F9F7F2] text-black' : 'bg-[#121212] text-white'
                    }`}
                  >
                    <option value="" disabled>
                      -- Choose a time slot --
                    </option>
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-xs text-white/50">
                    ▼
                  </div>
                </div>
                {errors.time && (
                  <p className="mt-1.5 text-xs text-rose-400 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.time}
                  </p>
                )}
              </div>
            </div>

            {/* Additional Message */}
            <div>
              <label className={`block text-xs font-semibold tracking-wider uppercase mb-2 ${
                isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
              }`}>
                Additional Message / Hair or Skin Requests (Optional)
              </label>
              <div className="relative">
                <MessageSquare className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-3.5 pointer-events-none" />
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Any previous hair color history, bridal event timings, or specific hair texture details..."
                  className={`w-full pl-10 pr-4 py-3 border focus:border-[#C6A15B] rounded-sm text-sm focus:outline-none transition-colors ${
                    isLight ? 'bg-[#F9F7F2] border-black/10 text-black placeholder-black/40' : 'bg-[#121212] border-white/10 text-white placeholder-white/30'
                  }`}
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-4 px-6 bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] hover:brightness-110 active:scale-[0.99] text-[#111111] font-semibold text-sm tracking-wider uppercase rounded-sm shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Continue on WhatsApp</span>
              </button>
              <p className={`text-center text-[11px] mt-2.5 ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/60'}`}>
                Will open WhatsApp with <strong>+91 86863 85552</strong> with all entered details formatted.
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
