import React from 'react';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Sparkles, Layers, HeartHandshake, MapPin } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/salonData';

export const WhyChooseUs: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const iconMap: Record<string, React.ElementType> = {
    Sparkles,
    Layers,
    HeartHandshake,
    MapPin,
  };

  return (
    <section className={`py-20 md:py-28 relative overflow-hidden transition-colors ${
      isLight ? 'bg-[#FFFFFF]' : 'bg-[#111111]'
    }`}>
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-96 bg-[#C6A15B]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              The Golden Wizard Standard
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Your Style, Our <span className="gold-gradient-text italic font-normal">Passion</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'}`}>
            We are dedicated to delivering thoughtful care, personalized consultations, and meticulous attention to detail on every visit.
          </p>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_CHOOSE_US.map((item, idx) => {
            const Icon = iconMap[item.icon] || Sparkles;
            return (
              <div
                key={idx}
                className={`group p-6 sm:p-7 rounded-sm border transition-all duration-300 flex flex-col justify-between hover:-translate-y-1.5 shadow-lg relative overflow-hidden ${
                  isLight
                    ? 'bg-[#F9F7F2] border-[#C6A15B]/25 hover:border-[#C6A15B] shadow-black/5'
                    : 'bg-[#171717] border-[#C6A15B]/20 hover:border-[#C6A15B]/60 shadow-black/40'
                }`}
              >
                {/* Gold corner accent */}
                <div className="absolute top-0 right-0 w-12 h-12 overflow-hidden pointer-events-none">
                  <div className="w-16 h-16 bg-[#C6A15B]/10 rotate-45 transform origin-bottom-left -translate-y-6 translate-x-6 group-hover:bg-[#C6A15B]/25 transition-colors" />
                </div>

                <div>
                  <div className="w-12 h-12 rounded-sm bg-[#111111] border border-[#C6A15B]/50 flex items-center justify-center text-[#C6A15B] mb-5 group-hover:border-[#C6A15B] group-hover:scale-105 transition-all shadow-md">
                    <Icon className="w-6 h-6 text-[#C6A15B]" />
                  </div>

                  <h3 className={`font-serif-elegant text-lg sm:text-xl font-semibold mb-3 group-hover:text-[#C6A15B] transition-colors leading-snug ${
                    isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
                  }`}>
                    {item.title}
                  </h3>

                  <p className={`text-xs sm:text-sm font-light leading-relaxed ${
                    isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/75'
                  }`}>
                    {item.description}
                  </p>
                </div>

                {/* Number indicator */}
                <div className="mt-6 pt-4 border-t border-black/5 dark:border-white/5 flex items-center justify-between text-xs">
                  <span className="text-[#C6A15B] font-mono font-bold">0{idx + 1}</span>
                  <span className="text-white/40 text-[10px] uppercase tracking-wider">Quality Care</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
