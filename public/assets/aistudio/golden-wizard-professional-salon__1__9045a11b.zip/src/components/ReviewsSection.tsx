import React from 'react';
import { GOOGLE_REVIEWS, SALON_INFO } from '../data/salonData';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Star, ExternalLink, Quote, CheckCircle2 } from 'lucide-react';

export const ReviewsSection: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  return (
    <section id="reviews" className={`py-20 md:py-28 relative overflow-hidden border-t border-b transition-colors ${
      isLight ? 'bg-[#FFFFFF] border-black/5' : 'bg-[#151515] border-white/5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Client Feedback
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            What Our Customers <span className="gold-gradient-text italic font-normal">Say</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          {/* Prominent Rating Score Card */}
          <div className={`mt-8 inline-flex flex-col sm:flex-row items-center gap-4 sm:gap-8 border px-6 sm:px-8 py-4 rounded-sm shadow-xl ${
            isLight
              ? 'bg-[#F9F7F2] border-[#C6A15B]/40 shadow-black/5'
              : 'bg-[#1B1B1B] border-[#C6A15B]/30'
          }`}>
            <div className="flex items-baseline gap-2">
              <span className={`font-serif-elegant text-4xl sm:text-5xl font-bold ${
                isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
              }`}>
                {SALON_INFO.rating}
              </span>
              <span className="text-lg text-[#C6A15B] font-light">/ 5.0</span>
            </div>

            <div className={`h-8 w-[1px] hidden sm:block ${isLight ? 'bg-black/10' : 'bg-white/10'}`} />

            <div className="flex flex-col items-center sm:items-start">
              <div className="flex items-center gap-1 text-[#C6A15B] mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#C6A15B] text-[#C6A15B]" />
                ))}
              </div>
              <div className={`flex items-center gap-1.5 text-xs ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]'}`}>
                <span className={`font-bold ${isLight ? 'text-black' : 'text-white'}`}>{SALON_INFO.reviewCount}</span>
                <span>Verified Google Reviews</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              </div>
            </div>
          </div>
        </div>

        {/* 3 Verified Google Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {GOOGLE_REVIEWS.map((review) => (
            <div
              key={review.id}
              className={`p-6 sm:p-7 rounded-sm border transition-all duration-300 flex flex-col justify-between shadow-lg hover:-translate-y-1 relative ${
                isLight
                  ? 'bg-[#F9F7F2] border-[#C6A15B]/25 hover:border-[#C6A15B] shadow-black/5'
                  : 'bg-[#191919] border-[#C6A15B]/20 hover:border-[#C6A15B]/50'
              }`}
            >
              <Quote className="w-8 h-8 text-[#C6A15B]/25 mb-3" />

              <blockquote className={`font-serif-elegant text-lg sm:text-xl leading-relaxed mb-6 font-normal italic ${
                isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
              }`}>
                "{review.quote}"
              </blockquote>

              <div className="pt-4 border-t border-black/5 dark:border-white/5 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1 text-[#C6A15B] mb-1">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#C6A15B] text-[#C6A15B]" />
                    ))}
                  </div>
                  <p className={`text-xs font-medium ${isLight ? 'text-[#3D3A34]' : 'text-[#EAE2D5]'}`}>{review.author}</p>
                </div>

                <div className="flex flex-col items-end">
                  <span className="text-[10px] uppercase tracking-wider text-[#C6A15B] font-semibold bg-[#C6A15B]/10 px-2 py-0.5 rounded">
                    {review.badge}
                  </span>
                  <span className="text-[10px] text-white/40 mt-1">Google</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Read More Google Reviews Link */}
        <div className="text-center">
          <a
            href={SALON_INFO.googleReviewsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-2 px-6 py-3 border text-xs sm:text-sm font-semibold tracking-wider rounded-sm transition-all shadow-md uppercase ${
              isLight
                ? 'bg-[#FFFFFF] hover:bg-[#F9F7F2] border-[#C6A15B]/50 text-[#1B1B1B] hover:text-[#C6A15B]'
                : 'bg-[#1B1B1B] hover:bg-[#242424] border-[#C6A15B]/40 hover:border-[#C6A15B] text-[#F8F5EF] hover:text-[#C6A15B]'
            }`}
          >
            <span>Read More Google Reviews</span>
            <ExternalLink className="w-4 h-4 text-[#C6A15B]" />
          </a>
          <p className="text-[11px] text-[#C6A15B]/70 mt-2">
            Opens Google Maps page for Golden Wizard Professional Salon, Gandi Maisamma
          </p>
        </div>
      </div>
    </section>
  );
};
