import React, { useState, useEffect } from 'react';
import { CrownIcon } from './CrownIcon';
import { SALON_INFO } from '../data/salonData';
import { useTheme } from '../context/ThemeContext';
import { Phone, MessageCircle, Menu, X, Calendar, Clock, MapPin, Sun, Moon, ShieldCheck, Lock, Star } from 'lucide-react';

interface NavbarProps {
  onOpenBookingModal?: () => void;
  onOpenAdminPortal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBookingModal, onOpenAdminPortal }) => {
  const { theme, toggleTheme } = useTheme();
  const isLight = theme === 'light';

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Credentials', href: '#certificates' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'Q&A', href: '#qa-section' },
    { name: 'Ask Question', href: '#ask-question-form' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleLinkClick = (href: string) => {
    setMobileMenuOpen(false);
    if (window.location.pathname !== '/') {
      window.history.pushState(null, '', `/${href}`);
      window.dispatchEvent(new PopStateEvent('popstate'));
      setTimeout(() => {
        const element = document.querySelector(href);
        if (element) element.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      return;
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Top micro announcement bar */}
      <div className={`border-b text-xs py-1.5 px-4 hidden md:block transition-colors ${
        isLight
          ? 'bg-[#EFEBE1] border-[#C6A15B]/30 text-[#4A453F]'
          : 'bg-[#161616] border-[#C6A15B]/20 text-[#EAE2D5]/80'
      }`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#C6A15B]" />
              Gandi Maisamma X Rd, Opp. Indian Oil Petrol Pump, Hyderabad
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#C6A15B]" />
              Open Daily until 9:00 PM
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[#C6A15B] font-semibold flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-[#C6A15B] text-[#C6A15B]" />
              <span>4.4 / 5 Google Rated (171 Reviews)</span>
            </span>
            <a
              href={`tel:${SALON_INFO.phoneRaw}`}
              className="hover:text-[#C6A15B] transition-colors flex items-center gap-1"
            >
              <Phone className="w-3 h-3 text-[#C6A15B]" />
              {SALON_INFO.phoneDisplay}
            </a>
            {onOpenAdminPortal && (
              <button
                onClick={onOpenAdminPortal}
                className="text-[11px] text-[#C6A15B] hover:underline flex items-center gap-1 ml-2 cursor-pointer"
              >
                <Lock className="w-3 h-3" />
                <span>Owner Portal</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main sticky navigation */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? isLight
              ? 'bg-[#FFFFFF]/95 backdrop-blur-md border-b border-[#C6A15B]/30 py-3 shadow-md'
              : 'bg-[#111111]/95 backdrop-blur-md border-b border-[#C6A15B]/25 py-3 shadow-lg shadow-black/40'
            : isLight
            ? 'bg-[#F8F5EF]/90 backdrop-blur-sm border-b border-black/5 py-4'
            : 'bg-[#111111]/80 backdrop-blur-sm border-b border-white/5 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('#home');
              }}
              className="flex items-center gap-2.5 sm:gap-3 group focus:outline-none"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-[#1E1E1E] to-[#121212] border border-[#C6A15B]/60 flex items-center justify-center text-[#C6A15B] shadow-[0_0_15px_rgba(198,161,91,0.2)] group-hover:border-[#C6A15B] transition-colors">
                <CrownIcon className="w-5 h-5 text-[#C6A15B] group-hover:scale-110 transition-transform" />
              </div>
              <div className="flex flex-col">
                <span className={`font-serif-elegant text-base sm:text-lg md:text-xl font-semibold tracking-wider uppercase transition-colors ${
                  isLight ? 'text-[#1B1B1B] group-hover:text-[#B89347]' : 'text-[#F8F5EF] group-hover:text-[#D6B979]'
                }`}>
                  Golden Wizard
                </span>
                <span className="text-[9px] sm:text-[10px] tracking-[0.25em] text-[#C6A15B] font-medium uppercase -mt-0.5">
                  Professional Salon
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleLinkClick(link.href);
                  }}
                  className={`text-xs xl:text-sm font-medium tracking-wide transition-colors duration-200 relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-[#C6A15B] hover:after:w-full after:transition-all after:duration-300 ${
                    isLight ? 'text-[#3D3A34] hover:text-[#B89347]' : 'text-[#EAE2D5] hover:text-[#C6A15B]'
                  }`}
                >
                  {link.name}
                </a>
              ))}
            </nav>

            {/* Right Action Buttons */}
            <div className="hidden sm:flex items-center gap-2.5">
              {/* Working Theme Switcher */}
              <button
                type="button"
                onClick={toggleTheme}
                title={`Switch to ${isLight ? 'Dark Mode' : 'Light Mode'}`}
                className={`p-2 rounded-full border transition-all cursor-pointer flex items-center gap-1.5 text-xs ${
                  isLight
                    ? 'bg-[#EFEBE1] border-[#C6A15B]/40 text-[#1B1B1B] hover:border-[#C6A15B]'
                    : 'bg-[#1C1C1C] border-white/15 text-[#D6B979] hover:border-[#C6A15B]'
                }`}
                aria-label="Toggle theme"
              >
                {isLight ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-[#B89347]" />
                    <span className="text-[11px] font-semibold">Dark</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-[#D6B979]" />
                    <span className="text-[11px] font-semibold">Light</span>
                  </>
                )}
              </button>

              <a
                href={`tel:${SALON_INFO.phoneRaw}`}
                className={`hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-sm transition-colors border ${
                  isLight
                    ? 'border-black/10 hover:border-[#C6A15B] text-[#1B1B1B]'
                    : 'border-white/10 hover:border-[#C6A15B]/40 text-[#EAE2D5]'
                }`}
              >
                <Phone className="w-3.5 h-3.5 text-[#C6A15B]" />
                <span>Call Us</span>
              </a>

              <a
                href="#booking"
                onClick={(e) => {
                  e.preventDefault();
                  if (onOpenBookingModal) {
                    onOpenBookingModal();
                  } else {
                    handleLinkClick('#booking');
                  }
                }}
                className="flex items-center gap-1.5 px-4 py-2 text-xs md:text-sm font-semibold tracking-wider text-[#111111] bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] hover:brightness-110 active:scale-95 transition-all shadow-[0_2px_12px_rgba(198,161,91,0.25)] rounded-sm uppercase"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Appointment</span>
              </a>
            </div>

            {/* Mobile Controls: Theme + WhatsApp + Hamburger */}
            <div className="flex sm:hidden items-center gap-2">
              <button
                type="button"
                onClick={toggleTheme}
                aria-label="Toggle theme"
                className={`w-8 h-8 rounded-full border flex items-center justify-center ${
                  isLight ? 'bg-white border-black/15 text-black' : 'bg-[#1B1B1B] border-white/15 text-[#C6A15B]'
                }`}
              >
                {isLight ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
              </button>
              <a
                href={`https://wa.me/${SALON_INFO.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="w-8 h-8 rounded-full bg-[#1B1B1B] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B]"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#C6A15B]" />
              </a>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className={`p-1.5 focus:outline-none rounded ${
                  isLight ? 'text-black' : 'text-[#EAE2D5]'
                }`}
                aria-label="Toggle navigation menu"
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Navigation */}
        <div
          className={`sm:hidden fixed inset-x-0 top-[58px] border-b shadow-2xl transition-all duration-300 overflow-hidden ${
            isLight ? 'bg-[#FFFFFF] border-[#C6A15B]/30' : 'bg-[#111111] border-[#C6A15B]/30'
          } ${
            mobileMenuOpen ? 'max-h-[580px] opacity-100 py-4 px-6' : 'max-h-0 opacity-0 py-0 px-6 pointer-events-none'
          }`}
        >
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(link.href);
                }}
                className={`text-base font-serif-elegant tracking-wide py-1.5 border-b transition-colors ${
                  isLight
                    ? 'border-black/5 text-[#1B1B1B] hover:text-[#B89347]'
                    : 'border-white/5 text-[#F8F5EF] hover:text-[#C6A15B]'
                }`}
              >
                {link.name}
              </a>
            ))}

            <div className="pt-2 flex flex-col gap-2">
              <a
                href="#booking"
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick('#booking');
                }}
                className="w-full text-center py-2.5 px-4 text-xs tracking-wider uppercase font-semibold text-[#111111] bg-gradient-to-r from-[#D6B979] to-[#C6A15B] rounded-sm shadow-md"
              >
                Book Your Appointment
              </a>
              {onOpenAdminPortal && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAdminPortal();
                  }}
                  className="w-full text-center py-2 px-3 bg-[#1B1B1B] text-[#C6A15B] border border-[#C6A15B]/40 rounded-sm text-xs flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Owner Admin Dashboard</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>
    </>
  );
};
