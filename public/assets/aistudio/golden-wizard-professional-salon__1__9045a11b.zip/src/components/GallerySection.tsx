import React, { useState, useEffect } from 'react';
import { salonDb, GalleryRecord } from '../services/db';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { X, ChevronLeft, ChevronRight, Eye, Sparkles } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const [galleryItems, setGalleryItems] = useState<GalleryRecord[]>(salonDb.getGallery());
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);

  useEffect(() => {
    setGalleryItems(salonDb.getGallery());
    return salonDb.subscribe(() => {
      setGalleryItems(salonDb.getGallery());
    });
  }, []);

  const filterTabs = [
    { id: 'all', label: 'All Portfolio' },
    { id: 'haircuts', label: 'Haircuts & Grooming' },
    { id: 'colour', label: 'Colouring & Balayage' },
    { id: 'bridal', label: 'Bridal Artistry' },
    { id: 'treatments', label: 'Treatments & Skin' },
    { id: 'salon', label: 'Salon Ambience' },
  ];

  const filteredItems = galleryItems.filter((item) => {
    if (activeFilter === 'all') return true;
    return item.category === activeFilter;
  });

  const openLightbox = (index: number) => {
    setSelectedImageIndex(index);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImageIndex(null);
    document.body.style.overflow = 'auto';
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex + 1) % filteredItems.length);
    }
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex(
        (selectedImageIndex - 1 + filteredItems.length) % filteredItems.length
      );
    }
  };

  return (
    <section id="gallery" className={`py-20 md:py-28 relative border-t border-b transition-colors ${
      isLight ? 'bg-[#F8F5EF] border-black/5' : 'bg-[#151515] border-white/5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Visual Portfolio
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Style <span className="gold-gradient-text italic font-normal">Inspiration</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light ${isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'}`}>
            Explore style inspiration across contemporary cuts, radiant balayage, festive bridal styling, and rejuvenating skin care.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {filterTabs.map((tab) => {
            const isActive = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id)}
                className={`px-4 py-1.5 rounded-sm text-xs font-medium tracking-wide transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#C6A15B] text-[#111111] font-semibold shadow-md'
                    : isLight
                    ? 'bg-[#EFEBE1] text-[#3D3A34] hover:bg-[#E5DFD3] border border-black/5'
                    : 'bg-[#1C1C1C] text-[#EAE2D5]/70 hover:text-[#F8F5EF] border border-white/5'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              onClick={() => openLightbox(index)}
              className={`group relative h-64 sm:h-72 rounded-sm overflow-hidden cursor-pointer border transition-all duration-300 shadow-md ${
                isLight
                  ? 'bg-white border-[#C6A15B]/25 hover:border-[#C6A15B]'
                  : 'bg-[#111111] border-[#C6A15B]/20 hover:border-[#C6A15B]/60'
              }`}
            >
              <img
                src={item.image}
                alt={item.alt}
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />

              {/* Hover Badge and Caption */}
              <div className="absolute inset-0 p-4 flex flex-col justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="self-end">
                  <span className="w-8 h-8 rounded-full bg-[#111111]/80 border border-[#C6A15B]/60 flex items-center justify-center text-[#C6A15B] shadow-lg">
                    <Eye className="w-4 h-4" />
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-semibold tracking-wider uppercase text-[#C6A15B] block mb-1">
                    {item.categoryLabel}
                  </span>
                  <h3 className="font-serif-elegant text-base font-semibold text-[#F8F5EF]">
                    {item.title}
                  </h3>
                </div>
              </div>

              {/* Bottom tag visible on mobile */}
              <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center sm:hidden group-hover:hidden">
                <span className="text-[10px] bg-black/75 backdrop-blur-sm px-2 py-0.5 rounded text-white/90">
                  {item.title}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Inspiration disclaimer */}
        <div className="mt-8 text-center">
          <p className={`text-xs italic ${isLight ? 'text-[#6B655B]' : 'text-[#EAE2D5]/60'}`}>
            * Style inspiration portfolio showcasing representative styling techniques and aesthetics. Visit Golden Wizard Professional Salon in Gandi Maisamma for personalized hair & beauty consultations.
          </p>
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImageIndex !== null && filteredItems[selectedImageIndex] && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={closeLightbox}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
        >
          {/* Close Button */}
          <button
            onClick={closeLightbox}
            aria-label="Close preview"
            className="absolute top-4 right-4 sm:top-6 sm:right-6 w-11 h-11 rounded-full bg-[#1B1B1B] border border-[#C6A15B]/50 text-[#F8F5EF] hover:text-[#C6A15B] flex items-center justify-center transition-colors z-50 cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Previous Button */}
          <button
            onClick={prevImage}
            aria-label="Previous image"
            className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#1B1B1B]/80 hover:bg-[#1B1B1B] border border-white/20 text-white flex items-center justify-center transition-all cursor-pointer z-50"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next Button */}
          <button
            onClick={nextImage}
            aria-label="Next image"
            className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#1B1B1B]/80 hover:bg-[#1B1B1B] border border-white/20 text-white flex items-center justify-center transition-all cursor-pointer z-50"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Image & Caption Container */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl w-full max-h-[85vh] flex flex-col items-center justify-center"
          >
            <img
              src={filteredItems[selectedImageIndex].image}
              alt={filteredItems[selectedImageIndex].alt}
              className="max-h-[70vh] w-auto max-w-full object-contain rounded-sm border border-[#C6A15B]/30 shadow-2xl"
            />
            <div className="mt-4 text-center">
              <span className="text-xs uppercase tracking-widest text-[#C6A15B] font-semibold">
                {filteredItems[selectedImageIndex].categoryLabel}
              </span>
              <h4 className="font-serif-elegant text-xl sm:text-2xl text-[#F8F5EF] mt-1">
                {filteredItems[selectedImageIndex].title}
              </h4>
              <p className="text-xs text-white/60 mt-1">
                Image {selectedImageIndex + 1} of {filteredItems.length}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
