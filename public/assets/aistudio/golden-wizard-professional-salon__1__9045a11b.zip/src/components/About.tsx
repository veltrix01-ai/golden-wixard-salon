import React from 'react';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Sparkles, Scissors, Palette, HeartHandshake } from 'lucide-react';

export const About: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const pillars = [
    {
      title: 'Professional Salon Atmosphere',
      desc: 'Step into an immaculate, fully air-conditioned, and hygienic environment crafted for total comfort and relaxation.',
      icon: Sparkles,
      image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80',
    },
    {
      title: 'Hair Styling & Grooming',
      desc: 'Contemporary haircuts, precise beard trimming, customized blowouts, and curling that accentuate your natural features.',
      icon: Scissors,
      image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80',
    },
    {
      title: 'Hair Colouring & Treatments',
      desc: 'Expert balayage, dimensional highlights, keratin smoothing, and deep repair hair spas using quality formulas.',
      icon: Palette,
      image: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=600&q=80',
    },
    {
      title: 'Beauty & Bridal Services',
      desc: 'Complete bridal hair, special event makeup, refreshing facials, de-tan treatments, and pampering hand-foot care.',
      icon: HeartHandshake,
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=600&q=80',
    },
  ];

  return (
    <section id="about" className={`py-20 md:py-28 relative overflow-hidden border-t border-b transition-colors ${
      isLight ? 'bg-[#F8F5EF] border-black/5' : 'bg-[#151515] border-white/5'
    }`}>
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-[#C6A15B]/5 rounded-full blur-[100px] pointer-events-none -translate-y-1/2" />
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-[#C6A15B]/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              About The Salon
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-6 tracking-tight">
            Experience the Art of <span className="gold-gradient-text italic font-normal">Beauty</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-base sm:text-lg leading-relaxed font-light ${
            isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/90'
          }`}>
            <strong className={`font-medium ${isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'}`}>
              Golden Wizard Professional Salon
            </strong> is a professional hair and beauty destination in Gandi Maisamma, Hyderabad. From everyday haircuts to modern colouring, styling and beauty treatments, discover services designed to help you express your personal style.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div
                key={index}
                className={`group relative rounded-sm overflow-hidden border transition-all duration-300 flex flex-col hover:-translate-y-1 shadow-lg ${
                  isLight
                    ? 'bg-[#FFFFFF] border-[#C6A15B]/30 hover:border-[#C6A15B] shadow-black/5'
                    : 'bg-[#1B1B1B] border-[#C6A15B]/20 hover:border-[#C6A15B]/60 shadow-black/40'
                }`}
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t via-transparent to-transparent ${
                    isLight ? 'from-[#FFFFFF]' : 'from-[#1B1B1B]'
                  }`} />
                  
                  {/* Floating icon */}
                  <div className="absolute bottom-3 left-4 w-10 h-10 rounded-full bg-[#111111]/90 border border-[#C6A15B]/50 flex items-center justify-center text-[#C6A15B] shadow-md">
                    <IconComponent className="w-5 h-5 text-[#C6A15B]" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className={`font-serif-elegant text-lg font-semibold mb-2 group-hover:text-[#C6A15B] transition-colors ${
                      isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
                    }`}>
                      {item.title}
                    </h3>
                    <p className={`text-xs sm:text-sm leading-relaxed font-light ${
                      isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'
                    }`}>
                      {item.desc}
                    </p>
                  </div>
                </div>

                {/* Subtle bottom accent line */}
                <div className="h-[2px] w-0 group-hover:w-full bg-gradient-to-r from-[#D6B979] to-[#C6A15B] transition-all duration-300" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
