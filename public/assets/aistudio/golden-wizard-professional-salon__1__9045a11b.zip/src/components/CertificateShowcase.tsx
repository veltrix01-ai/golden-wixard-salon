import React, { useState, useEffect } from 'react';
import { salonDb, Certificate } from '../services/db';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Award, ShieldCheck, Eye, X, ExternalLink, Lock } from 'lucide-react';

export const CertificateShowcase: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);
  const [showRightClickAlert, setShowRightClickAlert] = useState(false);

  useEffect(() => {
    setCertificates(salonDb.getCertificates());
    return salonDb.subscribe(() => {
      setCertificates(salonDb.getCertificates());
    });
  }, []);

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setShowRightClickAlert(true);
    setTimeout(() => setShowRightClickAlert(false), 2500);
  };

  return (
    <section id="certificates" className={`py-20 md:py-28 relative border-t border-b transition-colors ${
      isLight ? 'bg-[#FFFFFF] border-black/5' : 'bg-[#111111] border-white/5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Verified Credentials
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Recognition & Professional <span className="gold-gradient-text italic font-normal">Credentials</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light max-w-2xl mx-auto ${
            isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'
          }`}>
            Our stylists and salon practice adhere to leading technical certifications, international styling academies, and stringent hygiene accreditations.
          </p>
        </div>

        {/* Right-click deterrent banner */}
        {showRightClickAlert && (
          <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-[#1B1B1B] border border-[#C6A15B] text-[#F8F5EF] text-xs px-4 py-2.5 rounded-md shadow-2xl flex items-center gap-2 animate-bounce">
            <Lock className="w-4 h-4 text-[#C6A15B]" />
            <span>Document Protected: High-resolution originals are digitally watermarked and archived.</span>
          </div>
        )}

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              onClick={() => setSelectedCert(cert)}
              onContextMenu={handleContextMenu}
              className={`group relative rounded-sm border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer shadow-lg hover:-translate-y-1.5 select-none ${
                isLight
                  ? 'bg-[#F9F7F2] border-[#C6A15B]/30 hover:border-[#C6A15B] shadow-black/5'
                  : 'bg-[#181818] border-[#C6A15B]/25 hover:border-[#C6A15B]/70 shadow-black/50'
              }`}
            >
              {/* Certificate Image Frame with Watermark */}
              <div className="relative h-56 overflow-hidden bg-[#121212] flex items-center justify-center">
                <img
                  src={cert.imageUrl}
                  alt={cert.title}
                  draggable={false}
                  className="w-full h-full object-cover object-center filter contrast-95 group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />

                {/* Anti-copy watermark overlay */}
                <div className="absolute inset-0 bg-black/35 flex flex-col items-center justify-center pointer-events-none p-4 text-center">
                  <div className="text-[10px] sm:text-[11px] font-bold tracking-[0.25em] text-white/50 uppercase rotate-[-25deg] select-none border-y border-white/20 py-1 px-4">
                    GOLDEN WIZARD PROFESSIONAL SALON
                  </div>
                </div>

                {/* Gold Frame Corner Accents */}
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#C6A15B]" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#C6A15B]" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#C6A15B]" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#C6A15B]" />

                {/* View Overlay Button */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-sm bg-[#111111]/90 border border-[#C6A15B] text-xs font-semibold text-[#D6B979]">
                    <Eye className="w-3.5 h-3.5" />
                    Enlarge Preview
                  </span>
                </div>

                {/* Category Pill */}
                <div className="absolute top-3 left-3">
                  <span className="text-[9px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-sm bg-[#111111]/90 text-[#D6B979] border border-[#C6A15B]/40">
                    {cert.category}
                  </span>
                </div>
              </div>

              {/* Certificate Details */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-[#C6A15B] font-semibold mb-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{cert.issuingOrganization}</span>
                  </div>

                  <h3 className="font-serif-elegant text-base sm:text-lg font-bold mb-2 group-hover:text-[#C6A15B] transition-colors leading-snug">
                    {cert.title}
                  </h3>

                  <p className={`text-xs font-light leading-relaxed mb-4 line-clamp-3 ${
                    isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/70'
                  }`}>
                    {cert.description}
                  </p>
                </div>

                {/* Footer meta */}
                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#C6A15B]/80">
                  <span>Issued: {cert.issueDate || 'Verified'}</span>
                  <span className="flex items-center gap-1 text-[#C6A15B] font-medium group-hover:underline">
                    View Verified <Award className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Protection Notice Banner */}
        <div className={`mt-10 p-4 rounded-sm border text-center max-w-2xl mx-auto text-xs ${
          isLight
            ? 'bg-[#F9F7F2] border-[#C6A15B]/30 text-[#4A453F]'
            : 'bg-[#161616] border-white/10 text-white/60'
        }`}>
          <div className="flex items-center justify-center gap-1.5 text-[#C6A15B] font-semibold mb-1">
            <Lock className="w-3.5 h-3.5" />
            <span>Digital Document Protection & Authenticity Policy</span>
          </div>
          <p>
            Previews contain security watermarks. Certified physical and high-resolution originals are held securely by Golden Wizard Professional Salon management. Right-click copy is restricted.
          </p>
        </div>
      </div>

      {/* Enlarged Modal Preview */}
      {selectedCert && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setSelectedCert(null)}
          onContextMenu={handleContextMenu}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-2xl w-full bg-[#181818] border border-[#C6A15B]/50 rounded-sm p-6 shadow-2xl flex flex-col"
          >
            {/* Close Button */}
            <button
              onClick={() => setSelectedCert(null)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#111111] border border-[#C6A15B]/40 text-white hover:text-[#C6A15B] flex items-center justify-center cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Image with Watermark */}
            <div className="relative max-h-[55vh] overflow-hidden rounded bg-black flex items-center justify-center border border-[#C6A15B]/30 select-none">
              <img
                src={selectedCert.imageUrl}
                alt={selectedCert.title}
                draggable={false}
                className="max-h-[55vh] w-auto object-contain filter contrast-95"
              />
              <div className="absolute inset-0 bg-black/25 flex flex-col items-center justify-center pointer-events-none p-4 text-center">
                <div className="text-sm sm:text-base font-bold tracking-[0.3em] text-white/50 uppercase rotate-[-25deg] select-none border-y-2 border-[#C6A15B]/40 py-2 px-6">
                  GOLDEN WIZARD PROFESSIONAL SALON
                </div>
              </div>
            </div>

            {/* Modal Information */}
            <div className="mt-5 text-left">
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-4 h-4 text-[#C6A15B]" />
                <span className="text-xs uppercase tracking-wider text-[#C6A15B] font-bold">
                  {selectedCert.issuingOrganization}
                </span>
              </div>
              <h3 className="font-serif-elegant text-xl sm:text-2xl font-bold text-white mb-2">
                {selectedCert.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#EAE2D5]/80 font-light leading-relaxed mb-4">
                {selectedCert.description}
              </p>

              <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-white/60">
                <span>Certificate Ref: <strong className="text-white font-mono">{selectedCert.id}</strong></span>
                {selectedCert.verificationUrl && (
                  <a
                    href={selectedCert.verificationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#C6A15B] hover:underline"
                  >
                    <span>Issuer Accreditation Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
