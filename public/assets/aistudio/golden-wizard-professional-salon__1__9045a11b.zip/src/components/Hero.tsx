import React from 'react';
import { SALON_INFO } from '../data/salonData';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Star, Calendar, Sparkles, MapPin, ChevronDown, CheckCircle2, Phone } from 'lucide-react';

interface HeroProps {
  onExploreServices: () => void;
  onBookAppointment: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreServices, onBookAppointment }) => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const whatsappHeroUrl = `https://wa.me/${SALON_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Hello Golden Wizard Professional Salon! I would like to book an appointment. Please let me know available slots.'
  )}`;

  return (
    <section id="home" className="relative min-h-[90vh] md:min-h-screen flex items-center justify-center overflow-hidden transition-colors">
      {/* Background Image with Dark Luxury Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=2000&q=85"
          alt="Golden Wizard Professional Salon luxury interior styling stations with golden mirrors"
          className="w-full h-full object-cover object-center scale-105 animate-fade-in"
          loading="eager"
        />
        {/* Multilayered luxury gradient overlays */}
        <div className={`absolute inset-0 transition-opacity ${
          isLight
            ? 'bg-gradient-to-t from-[#F8F5EF] via-[#111111]/70 to-[#111111]/80'
            : 'bg-gradient-to-t from-[#111111] via-[#111111]/80 to-[#111111]/60'
        }`} />
        <div className="absolute inset-0 bg-radial-at-c from-transparent via-black/40 to-black/80" />
        {/* Subtle gold decorative glow */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#C6A15B]/15 rounded-full blur-[140px] pointer-events-none" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        {/* Decorative Gold Top Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1B1B1B]/90 border border-[#C6A15B]/50 backdrop-blur-md mb-6 shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
          <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          <span className="text-[11px] sm:text-xs font-semibold tracking-widest text-[#EAE2D5] uppercase">
            Gandi Maisamma • Hyderabad
          </span>
        </div>

        {/* Google Rating Badge */}
        <div className="flex items-center justify-center gap-2 mb-6">
          <div className="inline-flex items-center gap-2 bg-[#171717]/85 px-4 py-1.5 rounded-md border border-white/10 text-xs sm:text-sm text-[#F8F5EF] shadow-lg">
            <div className="flex text-[#D6B979]">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="w-3.5 h-3.5 fill-[#C6A15B] text-[#C6A15B]"
                />
              ))}
            </div>
            <span className="font-bold text-[#C6A15B]">{SALON_INFO.rating}/5</span>
            <span className="text-white/40">|</span>
            <span className="text-[#EAE2D5] font-medium">{SALON_INFO.reviewCount} Google Reviews</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-0.5 inline-block" />
          </div>
        </div>

        {/* Headline */}
        <h1 className="font-serif-elegant text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-[#F8F5EF] leading-[1.1] mb-6">
          Experience the Art of <span className="gold-gradient-text italic font-normal">Beauty.</span>
        </h1>

        {/* Gold Ornament Divider */}
        <div className="flex items-center justify-center gap-3 my-5">
          <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-r from-transparent to-[#C6A15B]" />
          <div className="w-2 h-2 rotate-45 border border-[#C6A15B] bg-[#C6A15B]/30" />
          <div className="h-[1px] w-12 sm:w-20 bg-gradient-to-l from-transparent to-[#C6A15B]" />
        </div>

        {/* Subheading */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-[#EAE2D5] font-light leading-relaxed mb-10 drop-shadow-sm">
          Discover premium hair styling, beauty care and professional salon experiences at <strong className="font-medium text-[#F8F5EF]">Golden Wizard Professional Salon</strong>.
        </p>

        {/* Three Prominent Actions (BOOK AN APPOINTMENT | CALL NOW | VISIT OUR SALON) */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 max-w-2xl mx-auto">
          {/* Action 1: BOOK AN APPOINTMENT */}
          <button
            type="button"
            onClick={onBookAppointment}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-bold tracking-wider text-[#111111] bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] hover:brightness-110 active:scale-95 transition-all shadow-[0_4px_24px_rgba(198,161,91,0.35)] rounded-sm uppercase min-w-[190px] cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Book an Appointment</span>
          </button>

          {/* Action 2: CALL NOW */}
          <a
            href={`tel:${SALON_INFO.phoneRaw}`}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-semibold tracking-wider text-[#F8F5EF] bg-[#1B1B1B]/95 hover:bg-[#252525] border border-[#C6A15B]/60 hover:border-[#C6A15B] transition-all rounded-sm uppercase min-w-[170px]"
          >
            <Phone className="w-4 h-4 text-[#C6A15B]" />
            <span>Call Now</span>
          </a>

          {/* Action 3: VISIT OUR SALON */}
          <a
            href={SALON_INFO.googleMapsDirectionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-medium tracking-wider text-[#EAE2D5] hover:text-white bg-[#151515]/80 hover:bg-[#1E1E1E] border border-white/15 hover:border-[#C6A15B]/50 transition-all rounded-sm uppercase min-w-[170px]"
          >
            <MapPin className="w-4 h-4 text-[#C6A15B]" />
            <span>Visit Our Salon</span>
          </a>
        </div>

        {/* Micro highlights underneath */}
        <div className="mt-12 pt-8 border-t border-white/15 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs text-[#EAE2D5]/80">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
            <span>Open daily until 9:00 PM</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
            <span>Opp. Indian Oil Petrol Pump, Gandi Maisamma</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
            <span>Phone: {SALON_INFO.phoneDisplay}</span>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="hidden md:flex justify-center mt-10">
          <button
            onClick={onExploreServices}
            className="text-white/50 hover:text-[#C6A15B] transition-colors flex flex-col items-center gap-1 text-xs cursor-pointer"
            aria-label="Scroll down"
          >
            <span className="tracking-widest uppercase text-[10px]">Discover</span>
            <ChevronDown className="w-4 h-4 animate-bounce" />
          </button>
        </div>
      </div>
    </section>
  );
};
