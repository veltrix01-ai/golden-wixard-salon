import React, { useState, useEffect } from 'react';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Search, HelpCircle, MessageSquare, Calendar, ChevronLeft, ChevronRight, ChevronDown, Sparkles, RefreshCw, AlertCircle } from 'lucide-react';

export interface PublicQuestionItem {
  id: string;
  question: string;
  asker_name?: string | null;
  answer?: string | null;
  answered_at?: string | null;
}

interface PublicQAResponse {
  questions: PublicQuestionItem[];
  total: number;
  page: number;
  totalPages: number;
  limit: number;
}

export const PublicQASection: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const [questions, setQuestions] = useState<PublicQuestionItem[]>([]);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Debounce search query
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(searchQuery);
      setCurrentPage(1); // Reset to page 1 on new search
    }, 300);
    return () => clearTimeout(handler);
  }, [searchQuery]);

  // Fetch answered questions from server
  const fetchQuestions = async (page: number, query: string) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        q: query,
      });

      const res = await fetch(`/api/questions?${params.toString()}`);
      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data: PublicQAResponse = await res.json();
      setQuestions(data.questions || []);
      setTotalQuestions(data.total || 0);
      setTotalPages(data.totalPages || 1);

      // Inject dynamic JSON-LD FAQPage Schema for published Q&A
      updateFaqSchema(data.questions || []);
    } catch (err) {
      console.error('Failed to load published questions:', err);
      setErrorMessage('Could not load answered questions at this time. Please try refreshing.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQuestions(currentPage, debouncedQuery);
  }, [currentPage, debouncedQuery]);

  // Inject or update JSON-LD FAQPage structured data
  const updateFaqSchema = (items: PublicQuestionItem[]) => {
    try {
      const existingScript = document.getElementById('faq-json-ld');
      if (existingScript) existingScript.remove();

      if (items.length === 0) return;

      const faqSchema = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: items
          .filter((item) => item.answer)
          .map((item) => ({
            '@type': 'Question',
            name: item.question,
            acceptedAnswer: {
              '@type': 'Answer',
              text: item.answer || '',
            },
          })),
      };

      const script = document.createElement('script');
      script.id = 'faq-json-ld';
      script.type = 'application/ld+json';
      script.text = JSON.stringify(faqSchema);
      document.head.appendChild(script);
    } catch (e) {
      console.warn('Failed to inject FAQ JSON-LD', e);
    }
  };

  const formatDate = (dateString?: string | null) => {
    if (!dateString) return 'Recently Answered';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return 'Recently';
    }
  };

  // Accordion open/collapse state (tracks expanded question IDs)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const toggleAccordion = (id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Auto-expand the first item when questions load
  useEffect(() => {
    if (questions.length > 0) {
      setExpandedIds(new Set([questions[0].id]));
    }
  }, [questions]);

  return (
    <section id="faqs" className={`py-20 md:py-28 relative border-t border-b transition-colors ${
      isLight ? 'bg-[#FFFFFF] border-black/5' : 'bg-[#131313] border-white/5'
    }`}>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 mb-3">
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
            <span className="text-xs font-semibold tracking-[0.25em] text-[#C6A15B] uppercase">
              Stylist Wisdom & Knowledge
            </span>
            <CrownIcon className="w-4 h-4 text-[#C6A15B]" />
          </div>

          <h2 className="font-serif-elegant text-3xl sm:text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Frequently Asked <span className="gold-gradient-text italic font-normal">Questions</span>
          </h2>

          <div className="flex items-center justify-center gap-3 my-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#C6A15B]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#C6A15B]" />
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#C6A15B]" />
          </div>

          <p className={`text-sm sm:text-base font-light max-w-2xl mx-auto ${
            isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/80'
          }`}>
            Browse verified answers published by Golden Wizard salon specialists regarding haircut maintenance, balayage longevity, keratin aftercare, and bridal services.
          </p>
        </div>

        {/* Live Search Input */}
        <div className="relative max-w-xl mx-auto mb-10">
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search answered questions (e.g. balayage, keratin, facial, haircut)..."
            className={`w-full pl-10 pr-10 py-3 rounded-sm text-xs sm:text-sm border focus:outline-none focus:border-[#C6A15B] transition-colors shadow-sm ${
              isLight
                ? 'bg-[#F9F7F2] border-black/10 text-black placeholder-black/40'
                : 'bg-[#1A1A1A] border-white/10 text-white placeholder-white/40'
            }`}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white text-xs cursor-pointer"
              aria-label="Clear search query"
            >
              ✕
            </button>
          )}
        </div>

        {/* Error Banner */}
        {errorMessage && (
          <div className="p-4 bg-rose-950/40 border border-rose-500/50 rounded-sm text-xs text-rose-300 flex items-center justify-between mb-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => fetchQuestions(currentPage, debouncedQuery)}
              className="underline hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Loading Skeletons */}
        {isLoading && (
          <div className="space-y-4">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className={`p-6 rounded-sm border animate-pulse space-y-3 ${
                  isLight ? 'bg-[#F9F7F2] border-black/5' : 'bg-[#181818] border-white/5'
                }`}
              >
                <div className="h-4 bg-white/10 rounded w-3/4" />
                <div className="h-3 bg-white/5 rounded w-1/4" />
                <div className="h-16 bg-white/5 rounded w-full mt-2" />
              </div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !errorMessage && questions.length === 0 && (
          <div className={`text-center py-16 px-4 rounded-sm border max-w-2xl mx-auto ${
            isLight ? 'bg-[#F9F7F2] border-[#C6A15B]/30' : 'bg-[#181818] border-[#C6A15B]/25'
          }`}>
            <HelpCircle className="w-12 h-12 text-[#C6A15B]/60 mx-auto mb-3" />
            <h3 className="font-serif-elegant text-xl sm:text-2xl font-bold mb-2 text-[#C6A15B]">
              No FAQs available yet. Have a question? Ask us!
            </h3>
            <p className={`text-xs sm:text-sm max-w-md mx-auto mb-6 ${isLight ? 'text-[#4A453F]' : 'text-white/70'}`}>
              {searchQuery
                ? `No published answers match "${searchQuery}". Clear your search or submit your question below.`
                : 'Be the first to submit a styling, hair treatment, or bridal query. Our salon stylists review enquiries daily and publish verified answers.'}
            </p>
            <a
              href="#ask-question-form"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-sm bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] text-[#111111] font-bold text-xs uppercase tracking-wider hover:brightness-110 active:scale-95 transition-all shadow-md"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask a Question Now</span>
            </a>
          </div>
        )}

        {/* Questions & Answers Accordion Layout */}
        {!isLoading && !errorMessage && questions.length > 0 && (
          <div className="space-y-4">
            {questions.map((item) => {
              const isExpanded = expandedIds.has(item.id);
              return (
                <div
                  key={item.id}
                  className={`rounded-sm border transition-all duration-300 overflow-hidden ${
                    isLight
                      ? 'bg-[#F9F7F2] border-[#C6A15B]/30 shadow-sm'
                      : 'bg-[#181818] border-[#C6A15B]/25'
                  } ${isExpanded ? 'border-[#C6A15B]' : ''}`}
                >
                  {/* Accordion Header (Click to Expand / Collapse) */}
                  <button
                    type="button"
                    onClick={() => toggleAccordion(item.id)}
                    className="w-full text-left p-5 sm:p-6 flex items-start justify-between gap-4 cursor-pointer focus:outline-none"
                    aria-expanded={isExpanded}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-7 h-7 rounded-full bg-[#C6A15B]/15 border border-[#C6A15B]/40 flex items-center justify-center shrink-0 mt-0.5 text-[#C6A15B] font-bold text-xs">
                        Q
                      </div>
                      <div>
                        <h3 className={`font-serif-elegant text-base sm:text-lg font-bold leading-snug transition-colors ${
                          isExpanded ? 'text-[#C6A15B]' : isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
                        }`}>
                          {item.question}
                        </h3>
                        <div className="text-[11px] opacity-60 mt-1 flex items-center gap-2">
                          <span>Asked by {item.asker_name ? item.asker_name : 'Customer'}</span>
                          {item.answered_at && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-[#C6A15B]" />
                                {formatDate(item.answered_at)}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className={`p-1.5 rounded-full border transition-transform duration-300 shrink-0 ${
                      isExpanded
                        ? 'bg-[#C6A15B] text-[#111111] border-[#C6A15B] rotate-180'
                        : 'border-white/10 text-white/50'
                    }`}>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {/* Accordion Content (Answer) */}
                  {isExpanded && item.answer && (
                    <div className={`px-5 pb-6 sm:px-6 sm:pb-6 pt-2 border-t flex items-start gap-3 animate-fade-in ${
                      isLight ? 'border-black/5 bg-[#FFFFFF]/60' : 'border-white/5 bg-[#141414]'
                    }`}>
                      <div className="w-7 h-7 rounded-full bg-[#111111] border border-[#C6A15B] flex items-center justify-center shrink-0 mt-0.5 text-[#C6A15B] shadow-sm">
                        <CrownIcon className="w-3.5 h-3.5" />
                      </div>
                      <div className="flex-1">
                        <div className="text-[11px] uppercase tracking-wider text-[#C6A15B] font-bold mb-1 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          <span>Golden Wizard Stylist Response</span>
                        </div>
                        <div className={`text-xs sm:text-sm leading-relaxed font-light ${
                          isLight ? 'text-[#2D2A24]' : 'text-[#EAE2D5]'
                        }`}>
                          {item.answer}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Pagination Controls (10 questions per page) */}
            {totalPages > 1 && (
              <div className="pt-6 flex items-center justify-between border-t border-black/5 dark:border-white/10 text-xs">
                <span className="opacity-60">
                  Showing page <strong className="text-[#C6A15B]">{currentPage}</strong> of{' '}
                  <strong className="text-[#C6A15B]">{totalPages}</strong> ({totalQuestions} total questions)
                </span>

                <div className="flex items-center gap-2">
                  <button
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    className="p-2 rounded border border-white/10 disabled:opacity-30 disabled:cursor-not-allowed hover:border-[#C6A15B] transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Previous</span>
                  </button>

                  {/* Page number indicators */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                      <button
                        key={p}
                        onClick={() => setCurrentPage(p)}
                        className={`w-7 h-7 rounded text-xs font-semibold cursor-pointer ${
                          currentPage === p
                            ? 'bg-[#C6A15B] text-[#111111]'
                            : isLight
                            ? 'bg-[#EFEBE1] text-black hover:bg-[#E5DFD3]'
                            : 'bg-[#1C1C1C] text-white hover:bg-[#252525]'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>

                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    className="p-2 rounded border border-white/10 disabled:opacity-30 disabled:cursor-not-allowed hover:border-[#C6A15B] transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
