import React, { useState, useRef } from 'react';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { Send, CheckCircle2, AlertCircle, ShieldCheck, Shield, HelpCircle } from 'lucide-react';
import { TurnstileWidget, TurnstileWidgetRef } from './TurnstileWidget';

export const AskQuestionForm: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';

  const [askerName, setAskerName] = useState('');
  const [questionText, setQuestionText] = useState('');
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const turnstileRef = useRef<TurnstileWidgetRef>(null);

  const charCount = questionText.length;
  const isTooShort = charCount > 0 && charCount < 10;
  const isTooLong = charCount > 500;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const trimmedQuestion = questionText.trim();

    if (trimmedQuestion.length < 10) {
      setErrorMessage('Your question must be at least 10 characters long.');
      return;
    }

    if (trimmedQuestion.length > 500) {
      setErrorMessage('Your question cannot exceed 500 characters.');
      return;
    }

    if (!turnstileToken) {
      setErrorMessage('Please complete the Cloudflare security verification before submitting.');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: trimmedQuestion,
          asker_name: askerName.trim() || null,
          turnstile_token: turnstileToken,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit question.');
      }

      setSuccessMessage(data.message || 'Thank you for your question! Our team will review it and publish an answer soon.');
      setQuestionText('');
      setAskerName('');
      setTurnstileToken(null);
      turnstileRef.current?.reset();
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred while submitting your question.');
      // Reset Turnstile on error so single-use token can be re-generated
      setTurnstileToken(null);
      turnstileRef.current?.reset();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="ask-question-form" className={`py-16 md:py-24 relative transition-colors ${
      isLight ? 'bg-[#F8F5EF]' : 'bg-[#111111]'
    }`}>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className={`border rounded-sm p-6 sm:p-10 shadow-2xl relative transition-all ${
          isLight
            ? 'bg-[#FFFFFF] border-[#C6A15B]/35 shadow-black/5'
            : 'bg-[#181818] border-[#C6A15B]/30'
        }`}>
          {/* Header */}
          <div className="text-center max-w-xl mx-auto mb-8">
            <div className="inline-flex items-center gap-1.5 mb-2 text-[#C6A15B]">
              <HelpCircle className="w-4 h-4" />
              <span className="text-xs font-semibold tracking-widest uppercase">Have a Query?</span>
            </div>
            <h3 className="font-serif-elegant text-2xl sm:text-3xl font-bold mb-2">
              Ask a Question to Our Salon Owner & Stylists
            </h3>
            <p className={`text-xs sm:text-sm font-light ${isLight ? 'text-[#4A453F]' : 'text-white/70'}`}>
              Submit your question without creating an account. The salon owner reviews every enquiry and publishes verified answers for the community.
            </p>
          </div>

          {/* Success Notification */}
          {successMessage && (
            <div className="mb-6 p-5 bg-emerald-950/40 border border-emerald-500/50 rounded-sm text-xs sm:text-sm text-emerald-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-emerald-300">
                  {successMessage}
                </p>
                <p className="text-xs text-emerald-200/80 mt-1">
                  Once answered by the salon owner, your question and its official advice will appear in Frequently Asked Questions.
                </p>
              </div>
            </div>
          )}

          {/* Error Notification */}
          {errorMessage && (
            <div className="mb-6 p-4 bg-rose-950/50 border border-rose-500/50 rounded-sm text-xs text-rose-300 flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            {/* 1. Customer Name (Optional) */}
            <div>
              <label className={`block text-xs font-semibold uppercase tracking-wider mb-1.5 ${
                isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
              }`}>
                Customer Name <span className="opacity-50 text-[10px] font-normal lowercase">(optional)</span>
              </label>
              <input
                type="text"
                value={askerName}
                maxLength={100}
                onChange={(e) => setAskerName(e.target.value)}
                placeholder="e.g. Priya Sharma (or leave blank to ask anonymously)"
                className={`w-full px-4 py-3 rounded-sm text-sm border focus:outline-none focus:border-[#C6A15B] transition-colors ${
                  isLight
                    ? 'bg-[#F9F7F2] border-black/10 text-black placeholder-black/40'
                    : 'bg-[#111111] border-white/10 text-white placeholder-white/30'
                }`}
              />
            </div>

            {/* 2. Question (Required, 10-500 characters) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#EAE2D5]'
                }`}>
                  Question <span className="text-[#C6A15B]">*</span>
                </label>
                <span className={`text-[11px] font-mono ${
                  isTooShort
                    ? 'text-amber-400'
                    : isTooLong
                    ? 'text-rose-400 font-bold'
                    : 'opacity-50'
                }`}>
                  {charCount} / 500 characters {isTooShort && '(min 10)'}
                </span>
              </div>
              <textarea
                rows={4}
                required
                value={questionText}
                maxLength={500}
                onChange={(e) => setQuestionText(e.target.value)}
                placeholder="Write your styling, treatment, or appointment question here (between 10 and 500 characters)..."
                className={`w-full p-4 rounded-sm text-sm border focus:outline-none transition-colors ${
                  isTooLong
                    ? 'border-rose-500 focus:border-rose-500'
                    : 'focus:border-[#C6A15B]'
                } ${
                  isLight
                    ? 'bg-[#F9F7F2] border-black/10 text-black placeholder-black/40'
                    : 'bg-[#111111] border-white/10 text-white placeholder-white/30'
                }`}
              />
            </div>

            {/* 3. Cloudflare Turnstile Verification Widget */}
            <TurnstileWidget
              ref={turnstileRef}
              isLight={isLight}
              onVerify={(token) => setTurnstileToken(token)}
              onExpire={() => setTurnstileToken(null)}
              onError={(errCode) => {
                console.warn('[AskQuestionForm] Turnstile error:', errCode);
                setTurnstileToken(null);
              }}
            />

            {/* Rate limit advisory - NO EMOJIS */}
            <div className="flex items-center justify-center gap-1.5 text-[11px] opacity-60 text-center">
              <Shield className="w-3.5 h-3.5 text-[#C6A15B] shrink-0" />
              <span>Maximum 5 questions per hour per IP. Submitted questions are stored privately until verified by the salon owner.</span>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !turnstileToken || charCount < 10 || charCount > 500}
              className="w-full py-4 px-6 bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] text-[#111111] font-bold text-xs sm:text-sm tracking-wider uppercase rounded-sm shadow-xl flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Submitting Question...' : 'Submit Question'}</span>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
