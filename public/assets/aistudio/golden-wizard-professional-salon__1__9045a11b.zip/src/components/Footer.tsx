import React from 'react';
import { SALON_INFO } from '../data/salonData';
import { CrownIcon } from './CrownIcon';
import { useTheme } from '../context/ThemeContext';
import { MapPin, Phone, MessageCircle, Navigation, Clock, Star, Lock } from 'lucide-react';

interface FooterProps {
  onOpenAdminPortal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdminPortal }) => {
  const { theme } = useTheme();
  const isLight = theme === 'light';
  const currentYear = new Date().getFullYear();

  const handleNavClick = (href: string) => {
    if (window.location.pathname !== '/') {
      window.history.pushState(null, '', `/${href}`);
      window.dispatchEvent(new PopStateEvent('popstate'));
      setTimeout(() => {
        const el = document.querySelector(href);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      return;
    }
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className={`border-t pt-16 pb-28 md:pb-16 relative transition-colors ${
      isLight ? 'bg-[#EAE2D5] border-[#C6A15B]/30 text-[#3D3A34]' : 'bg-[#0C0C0C] border-[#C6A15B]/20 text-[#EAE2D5]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-black/10 dark:border-white/10">
          {/* Col 1: Salon Identity (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#181818] border border-[#C6A15B]/60 flex items-center justify-center text-[#C6A15B] shadow-md">
                <CrownIcon className="w-5 h-5 text-[#C6A15B]" />
              </div>
              <div className="flex flex-col">
                <span className={`font-serif-elegant text-lg font-bold tracking-wider uppercase ${
                  isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
                }`}>
                  Golden Wizard
                </span>
                <span className="text-[10px] tracking-[0.25em] text-[#C6A15B] font-medium uppercase -mt-0.5">
                  Professional Salon
                </span>
              </div>
            </div>

            <p className={`text-xs sm:text-sm font-light leading-relaxed ${
              isLight ? 'text-[#4A453F]' : 'text-[#EAE2D5]/70'
            }`}>
              Experience the pinnacle of hair care, modern colour craft, hair straightening, rejuvenating facials, and bridal elegance in Gandi Maisamma, Hyderabad.
            </p>

            {/* Google Rating Chip */}
            <div className={`inline-flex items-center gap-2 p-2 px-3 rounded border text-xs ${
              isLight ? 'bg-white border-black/10' : 'bg-[#161616] border-white/10'
            }`}>
              <div className="flex text-[#C6A15B]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-[#C6A15B] text-[#C6A15B]" />
                ))}
              </div>
              <span className={`font-semibold ${isLight ? 'text-black' : 'text-white'}`}>{SALON_INFO.rating}/5</span>
              <span className="opacity-40">|</span>
              <span className="text-[#C6A15B] font-medium">{SALON_INFO.reviewCount} Google Reviews</span>
            </div>
          </div>

          {/* Col 2: Quick Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className={`font-serif-elegant text-base font-semibold tracking-wide uppercase ${
              isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
            }`}>
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a
                  href="#home"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#home');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#about"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#about');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  About the Salon
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#services');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Services & Treatments
                </a>
              </li>
              <li>
                <a
                  href="#certificates"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#certificates');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Credentials & Accreditations
                </a>
              </li>
              <li>
                <a
                  href="#gallery"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#gallery');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Style Gallery
                </a>
              </li>
              <li>
                <a
                  href="#reviews"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#reviews');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Client Reviews
                </a>
              </li>
              <li>
                <a
                  href="#qa-section"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#qa-section');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Questions & Answers (Q&A)
                </a>
              </li>
              <li>
                <a
                  href="#ask-question-form"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#ask-question-form');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Ask a Question
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick('#contact');
                  }}
                  className="hover:text-[#C6A15B] transition-colors"
                >
                  Location & Hours
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Services Offered (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className={`font-serif-elegant text-base font-semibold tracking-wide uppercase ${
              isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
            }`}>
              Featured Services
            </h4>
            <ul className="grid grid-cols-1 gap-1.5 text-xs opacity-80">
              <li className="hover:text-[#C6A15B] transition-colors">• Precision Haircuts & Styling</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Balayage & Hair Highlighting</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Keratin & Hair Treatments</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Permanent Straightening & Perms</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Hair Regrowth Scalp Care</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Bridal Hair & Wedding Makeovers</li>
              <li className="hover:text-[#C6A15B] transition-colors">• De-tan Glow Facials & Skin Care</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Classic Shave & Men's Grooming</li>
              <li className="hover:text-[#C6A15B] transition-colors">• Pampering Manicure & Pedicure</li>
            </ul>
          </div>

          {/* Col 4: Contact & Location (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className={`font-serif-elegant text-base font-semibold tracking-wide uppercase ${
              isLight ? 'text-[#1B1B1B]' : 'text-[#F8F5EF]'
            }`}>
              Salon Location
            </h4>
            <div className="space-y-3 text-xs opacity-90">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#C6A15B] shrink-0 mt-0.5" />
                <span>
                  4, Gandi Maisamma X Rd, <br />
                  <strong className="text-[#C6A15B] font-semibold">Opposite Indian Oil Petrol Pump</strong>, <br />
                  Gandi Maisamma, Hyderabad, Telangana 500043.
                </span>
              </p>

              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#C6A15B] shrink-0" />
                <a href={`tel:${SALON_INFO.phoneRaw}`} className="hover:text-[#C6A15B] transition-colors font-semibold">
                  {SALON_INFO.phoneDisplay}
                </a>
              </p>

              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C6A15B] shrink-0" />
                <span>Open daily until 9:00 PM</span>
              </p>

              <div className="pt-2 flex flex-col gap-2">
                <a
                  href={SALON_INFO.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#C6A15B] hover:underline font-medium"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Get Directions on Google Maps</span>
                </a>
                <a
                  href={`https://wa.me/${SALON_INFO.whatsappNumber}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#C6A15B] hover:underline font-medium"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Enquire on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Attribution */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs opacity-60">
          <p>© {currentYear} Golden Wizard Professional Salon. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Gandi Maisamma, Hyderabad • Telangana 500043</span>
            {onOpenAdminPortal && (
              <button
                onClick={onOpenAdminPortal}
                className="hover:text-[#C6A15B] transition-colors flex items-center gap-1 text-[11px] underline cursor-pointer"
              >
                <Lock className="w-3 h-3 text-[#C6A15B]" />
                <span>Salon Owner Portal</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
