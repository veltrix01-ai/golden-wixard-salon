export interface ServiceItem {
  id: string;
  name: string;
  category: 'hair' | 'treatments' | 'bridal' | 'beauty';
  categoryLabel: string;
  description: string;
  image: string;
  duration?: string;
  idealFor?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'haircuts' | 'colour' | 'bridal' | 'treatments' | 'salon';
  categoryLabel: string;
  image: string;
  alt: string;
}

export const SALON_INFO = {
  name: 'Golden Wizard Professional Salon',
  shortName: 'Golden Wizard',
  category: 'Professional Hair & Beauty Salon',
  rating: 4.4,
  reviewCount: 171,
  phoneDisplay: '+91 86863 85552',
  phoneRaw: '+918686385552',
  whatsappNumber: '918686385552',
  address: {
    line1: '4, Gandi Maisamma X Rd',
    landmark: 'Opposite Indian Oil Petrol Pump',
    area: 'Gandi Maisamma',
    city: 'Hyderabad',
    state: 'Telangana',
    pincode: '500043',
    full: '4, Gandi Maisamma X Rd, Opposite Indian Oil Petrol Pump, Gandi Maisamma, Hyderabad, Telangana 500043',
  },
  hours: 'Open daily until 9:00 PM (9:00 AM – 9:00 PM)',
  googleMapsDirectionsUrl:
    'https://www.google.com/maps/dir/?api=1&destination=Golden+Wizard+Professional+Salon+Gandi+Maisamma+Hyderabad+500043',
  googleMapsSearchUrl:
    'https://www.google.com/maps/search/?api=1&query=Golden+Wizard+Professional+Salon+Gandi+Maisamma+Hyderabad',
  googleReviewsUrl:
    'https://www.google.com/maps/search/?api=1&query=Golden+Wizard+Professional+Salon+Gandi+Maisamma+Hyderabad',
};

export const SERVICES: ServiceItem[] = [
  // CATEGORY 1: HAIR SERVICES
  {
    id: 'haircut',
    name: 'Haircut',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Precision cutting tailored to your face shape, hair texture, and individual lifestyle.',
    image: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=800&q=80',
    duration: '30-45 mins',
  },
  {
    id: 'hairstyling',
    name: 'Hairstyling',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Expert event and everyday styling that sculpts volume, definition, and sophisticated finish.',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
    duration: '40-60 mins',
  },
  {
    id: 'blow-dry',
    name: 'Blow Dry',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Smooth, salon-fresh blow-outs giving luminous shine, bounce, and effortless movement.',
    image: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=800&q=80',
    duration: '30 mins',
  },
  {
    id: 'hair-straightening',
    name: 'Hair Straightening',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Long-lasting sleek, silky, and frizz-free straightening using professional salon care formulas.',
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=800&q=80',
    duration: '2-3 hours',
  },
  {
    id: 'curly-hair-styling',
    name: 'Curly Hair Styling',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Specialized curl hydration, definition, and shaping techniques that celebrate natural waves and coils.',
    image: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=800&q=80',
    duration: '45-60 mins',
  },
  {
    id: 'braiding',
    name: 'Braiding',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Intricate and traditional hair braiding styles designed with clean sectioning and lasting hold.',
    image: 'https://images.unsplash.com/photo-1605497788044-5a32c7078486?auto=format&fit=crop&w=800&q=80',
    duration: '45-90 mins',
  },
  {
    id: 'childrens-cuts',
    name: "Children's Haircuts",
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Patient, gentle, and trendy haircuts designed in a friendly, comfortable setting for kids.',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&q=80',
    duration: '20-30 mins',
  },
  {
    id: 'shampoo-conditioning',
    name: 'Shampoo and Conditioning',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Invigorating scalp cleansing and deep moisture conditioning bath for soft, healthy hair.',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&w=800&q=80',
    duration: '20-30 mins',
  },
  {
    id: 'perms',
    name: 'Perms',
    category: 'hair',
    categoryLabel: 'Hair Services',
    description: 'Modern texturizing and perming to add enduring bounce, curls, or beachy volume.',
    image: 'https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=800&q=80',
    duration: '2-3 hours',
  },

  // CATEGORY 2: HAIR COLOURING & TREATMENTS
  {
    id: 'hair-colouring',
    name: 'Hair Colouring',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Full-coverage, gloss-infused global colour customized to enhance your skin tone and personality.',
    image: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=800&q=80',
    duration: '90-120 mins',
  },
  {
    id: 'hair-highlighting',
    name: 'Hair Highlighting',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Dimensional foil highlights and babylights adding sun-kissed depth and radiant contrast.',
    image: 'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=800&q=80',
    duration: '2-3 hours',
  },
  {
    id: 'balayage',
    name: 'Balayage',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Hand-painted seamless colour transition delivering an effortlessly blended, low-maintenance glow.',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&w=800&q=80',
    duration: '2.5-3.5 hours',
  },
  {
    id: 'keratin-treatments',
    name: 'Keratin Treatments',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Intense protein therapy that restores damaged cuticles, banishes frizz, and locks in mirror shine.',
    image: 'https://images.unsplash.com/photo-1522337094346-2918b300186a?auto=format&fit=crop&w=800&q=80',
    duration: '2-3 hours',
  },
  {
    id: 'hair-treatments',
    name: 'Hair Treatments',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Customized deep repair masks, hair spa, and moisture infusions targeting dryness and breakage.',
    image: 'https://images.unsplash.com/photo-1582095133179-bfd08e2fc6b3?auto=format&fit=crop&w=800&q=80',
    duration: '45-60 mins',
  },
  {
    id: 'hair-regrowth-services',
    name: 'Hair Regrowth Services',
    category: 'treatments',
    categoryLabel: 'Colour & Treatments',
    description: 'Targeted scalp stimulation and revitalizing nourishing sessions aimed at strengthening hair roots.',
    image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&w=800&q=80',
    duration: '60 mins',
  },

  // CATEGORY 3: BRIDAL & MAKEUP
  {
    id: 'bridal-hair',
    name: 'Bridal Hair',
    category: 'bridal',
    categoryLabel: 'Bridal & Makeup',
    description: 'Exquisite bridal updos, romantic cascades, and floral styling crafted for your special day.',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80',
    duration: '60-90 mins',
  },
  {
    id: 'bridal-services',
    name: 'Bridal Services',
    category: 'bridal',
    categoryLabel: 'Bridal & Makeup',
    description: 'Comprehensive pre-wedding and wedding-day grooming, skin prep, and bespoke beauty packages.',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=800&q=80',
    duration: 'Consultation based',
  },
  {
    id: 'makeup-services',
    name: 'Makeup Services',
    category: 'bridal',
    categoryLabel: 'Bridal & Makeup',
    description: 'Flawless makeup for weddings, receptions, parties, and celebrations highlighting your best features.',
    image: 'https://images.unsplash.com/photo-1503236823255-94609f598e71?auto=format&fit=crop&w=800&q=80',
    duration: '60-75 mins',
  },

  // CATEGORY 4: BEAUTY & GROOMING
  {
    id: 'shaving',
    name: 'Shaving & Beard Grooming',
    category: 'beauty',
    categoryLabel: 'Beauty & Grooming',
    description: 'Classic wet shave with warm towel finish, sharp line-ups, and luxury beard conditioning.',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&q=80',
    duration: '25-35 mins',
  },
  {
    id: 'detan-facial',
    name: 'De-tan and Facial',
    category: 'beauty',
    categoryLabel: 'Beauty & Grooming',
    description: 'Skin rejuvenating de-tanning and glow facials to clear pollutants, restore radiance, and revitalize skin.',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80',
    duration: '45-60 mins',
  },
  {
    id: 'manicure-pedicure',
    name: 'Manicure and Pedicure',
    category: 'beauty',
    categoryLabel: 'Beauty & Grooming',
    description: 'Pampering hand and foot spa rituals, cuticle care, gentle exfoliation, and nail shaping.',
    image: 'https://images.unsplash.com/photo-1519014816548-bf785179c2ff?auto=format&fit=crop&w=800&q=80',
    duration: '45-75 mins',
  },
];

export const GOOGLE_REVIEWS = [
  {
    id: 'rev-1',
    author: 'Verified Google Reviewer',
    rating: 5,
    quote: 'Hygienic place with good service.',
    badge: 'Verified Customer',
    date: 'Recent Google Review',
  },
  {
    id: 'rev-2',
    author: 'Verified Google Reviewer',
    rating: 5,
    quote: 'Highly recommend this salon for top-notch grooming and styling services!',
    badge: 'Local Guide',
    date: 'Recent Google Review',
  },
  {
    id: 'rev-3',
    author: 'Verified Google Reviewer',
    rating: 5,
    quote: 'Work and behaviour both are equally good.',
    badge: 'Verified Customer',
    date: 'Recent Google Review',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Modern Precision Haircut',
    category: 'haircuts',
    categoryLabel: 'Haircuts',
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1200&q=80',
    alt: 'Modern haircut styling in luxury salon environment',
  },
  {
    id: 'gal-2',
    title: 'Sun-Kissed Balayage Glow',
    category: 'colour',
    categoryLabel: 'Colouring',
    image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&w=1200&q=80',
    alt: 'Balayage hair colouring transformation with luminous gradient',
  },
  {
    id: 'gal-3',
    title: 'Luxury Salon Ambience',
    category: 'salon',
    categoryLabel: 'Salon Interior',
    image: 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&w=1200&q=80',
    alt: 'Golden Wizard Professional Salon luxurious interior styling stations',
  },
  {
    id: 'gal-4',
    title: 'Elegant Bridal Hair Artistry',
    category: 'bridal',
    categoryLabel: 'Bridal',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
    alt: 'Intricate wedding hair styling with floral elegance',
  },
  {
    id: 'gal-5',
    title: 'Keratin Smooth & Silk Finish',
    category: 'treatments',
    categoryLabel: 'Treatments',
    image: 'https://images.unsplash.com/photo-1522337094346-2918b300186a?auto=format&fit=crop&w=1200&q=80',
    alt: 'Silky smooth keratin treatment results',
  },
  {
    id: 'gal-6',
    title: 'Sharp Men’s Grooming & Styling',
    category: 'haircuts',
    categoryLabel: 'Grooming',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1200&q=80',
    alt: 'Sharp men grooming, beard trimming, and haircut styling',
  },
  {
    id: 'gal-7',
    title: 'Dimensional Hair Highlights',
    category: 'colour',
    categoryLabel: 'Colouring',
    image: 'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=1200&q=80',
    alt: 'Radiant hair highlighting and gloss finish',
  },
  {
    id: 'gal-8',
    title: 'Revitalizing Facial & Skin Care',
    category: 'treatments',
    categoryLabel: 'Skin & Facial',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=1200&q=80',
    alt: 'De-tan facial and rejuvenating skin care therapy',
  },
];

export const WHY_CHOOSE_US = [
  {
    title: 'Professional Hair & Beauty Services',
    description:
      'From classic scissor cuts to advanced keratin therapy, every service is performed with precision technique and premium salon-grade products.',
    icon: 'Sparkles',
  },
  {
    title: 'Multiple Styling & Treatment Options',
    description:
      'A comprehensive suite of 20+ specialized services including balayage, perms, curly hair care, bridal makeovers, and grooming under one roof.',
    icon: 'Layers',
  },
  {
    title: 'Welcoming Salon Experience',
    description:
      'A hygienic, comfortable, and courteous environment where our team listens attentively to your preferences and ensures a relaxing visit.',
    icon: 'HeartHandshake',
  },
  {
    title: 'Convenient Gandi Maisamma Location',
    description:
      'Centrally located on Gandi Maisamma X Road right opposite the Indian Oil Petrol Pump, with accessible parking and easy transit connections.',
    icon: 'MapPin',
  },
];
