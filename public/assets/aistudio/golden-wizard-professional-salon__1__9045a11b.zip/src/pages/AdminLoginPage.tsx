import React, { useState } from 'react';
import { CrownIcon } from '../components/CrownIcon';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowLeft,
  KeyRound,
  Shield,
  Zap,
  CheckCircle2,
} from 'lucide-react';

interface AdminLoginPageProps {
  onLoginSuccess: (token: string, username: string) => void;
  onNavigateHome: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onLoginSuccess, onNavigateHome }) => {
  const [loginMode, setLoginMode] = useState<'credentials' | 'pin'>('credentials');
  const [username, setUsername] = useState('goldenwizard_admin');
  const [password, setPassword] = useState('goldenwizard_secure_pass_2026');
  const [pin, setPin] = useState('1234');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberSession, setRememberSession] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const performLogin = async (loginUser: string, loginPass: string) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: loginUser.trim(),
          password: loginPass.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed. Please verify credentials.');
      }

      const token = data.token || 'gw_master_session_token_2026';
      const user = data.username || loginUser.trim() || 'goldenwizard_admin';

      // Store in both localStorage and sessionStorage
      if (rememberSession) {
        localStorage.setItem('gw_admin_token', token);
        localStorage.setItem('gw_admin_username', user);
      }
      sessionStorage.setItem('gw_admin_token', token);
      sessionStorage.setItem('gw_admin_username', user);
      sessionStorage.setItem('gw_admin_authenticated', 'true');

      onLoginSuccess(token, user);
    } catch (err: any) {
      setErrorMessage(err.message || 'Authentication failed. Please check credentials or try 1-Click Login.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginMode === 'credentials') {
      if (!username.trim() || !password) {
        setErrorMessage('Please enter both username and password.');
        return;
      }
      performLogin(username, password);
    } else {
      if (!pin.trim()) {
        setErrorMessage('Please enter your 4-digit PIN.');
        return;
      }
      performLogin('admin', pin);
    }
  };

  const handleQuickDemoLogin = () => {
    performLogin('goldenwizard_admin', 'goldenwizard_secure_pass_2026');
  };

  const handleFillDefaults = () => {
    setUsername('goldenwizard_admin');
    setPassword('goldenwizard_secure_pass_2026');
    setPin('1234');
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#C6A15B]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-md w-full bg-[#181818] border border-[#C6A15B]/40 rounded-sm p-6 sm:p-8 shadow-2xl relative z-10 text-white">
        {/* Return to website */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onNavigateHome}
            className="inline-flex items-center gap-1.5 text-xs text-[#EAE2D5]/70 hover:text-[#C6A15B] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Public Website</span>
          </button>
          <span className="text-[10px] text-[#C6A15B] uppercase tracking-wider font-semibold border border-[#C6A15B]/30 px-2 py-0.5 rounded">
            Owner Portal
          </span>
        </div>

        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-full bg-[#111111] border border-[#C6A15B] flex items-center justify-center text-[#C6A15B] mx-auto mb-3 shadow-[0_0_20px_rgba(198,161,91,0.25)]">
            <CrownIcon className="w-7 h-7 text-[#C6A15B]" />
          </div>
          <h1 className="font-serif-elegant text-2xl font-bold uppercase tracking-wider text-[#F8F5EF]">
            Golden Wizard
          </h1>
          <p className="text-[10px] tracking-[0.25em] text-[#C6A15B] uppercase font-semibold">
            Salon Owner & Manager Board
          </p>
        </div>

        {/* One-Click Quick Sign In Button */}
        <div className="mb-5">
          <button
            type="button"
            onClick={handleQuickDemoLogin}
            disabled={isLoading}
            className="w-full py-2.5 px-3 bg-[#241F14] hover:bg-[#322A1A] border border-[#C6A15B] text-[#D6B979] text-xs font-semibold rounded-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md group"
          >
            <Zap className="w-4 h-4 text-[#C6A15B] group-hover:scale-110 transition-transform" />
            <span>Instant 1-Click Owner Sign In</span>
          </button>
        </div>

        {/* Mode Selector (Username/Password vs Quick PIN) */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#111111] border border-white/10 rounded-sm mb-5 text-xs font-medium">
          <button
            type="button"
            onClick={() => {
              setLoginMode('credentials');
              setErrorMessage(null);
            }}
            className={`py-2 text-center rounded-sm transition-all cursor-pointer ${
              loginMode === 'credentials'
                ? 'bg-[#C6A15B] text-[#111111] font-bold shadow'
                : 'text-white/60 hover:text-white'
            }`}
          >
            Username & Password
          </button>
          <button
            type="button"
            onClick={() => {
              setLoginMode('pin');
              setErrorMessage(null);
            }}
            className={`py-2 text-center rounded-sm transition-all cursor-pointer ${
              loginMode === 'pin'
                ? 'bg-[#C6A15B] text-[#111111] font-bold shadow'
                : 'text-white/60 hover:text-white'
            }`}
          >
            4-Digit PIN (1234)
          </button>
        </div>

        {/* Security / Help Info */}
        <div className="p-3 bg-[#121212] rounded border border-white/10 mb-5 text-xs space-y-1">
          <div className="flex items-center gap-1.5 text-[#C6A15B] font-semibold text-[11px] uppercase tracking-wide">
            <Shield className="w-3.5 h-3.5" />
            <span>Authorized Owner Access</span>
          </div>
          <div className="text-[11px] text-white/70">
            {loginMode === 'credentials' ? (
              <span>
                Username: <strong className="text-white">goldenwizard_admin</strong> (or <strong className="text-white">admin</strong>) • Password: <strong className="text-white">goldenwizard_secure_pass_2026</strong>
              </span>
            ) : (
              <span>
                Default Salon Owner PIN: <strong className="text-[#C6A15B] font-mono text-xs">1234</strong>
              </span>
            )}
          </div>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-rose-950/60 border border-rose-500/50 rounded text-xs text-rose-300 mb-4 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <div className="flex-1">
              <p>{errorMessage}</p>
              <button
                type="button"
                onClick={handleFillDefaults}
                className="mt-1 text-[11px] text-[#C6A15B] underline hover:text-[#D6B979] cursor-pointer"
              >
                Reset to default credentials
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {loginMode === 'credentials' ? (
            <>
              {/* Username */}
              <div>
                <label className="block text-xs font-semibold text-[#EAE2D5] uppercase tracking-wider mb-1.5">
                  Owner Username
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="goldenwizard_admin"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#111111] border border-white/15 focus:border-[#C6A15B] rounded-sm text-sm text-[#F8F5EF] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-[#EAE2D5] uppercase tracking-wider mb-1.5">
                  Owner Password
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-[#111111] border border-white/15 focus:border-[#C6A15B] rounded-sm text-sm text-[#F8F5EF] focus:outline-none transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                    aria-label="Toggle password visibility"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* PIN Mode */
            <div>
              <label className="block text-xs font-semibold text-[#EAE2D5] uppercase tracking-wider mb-1.5">
                Owner 4-Digit Access PIN
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-[#C6A15B] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="1234"
                  maxLength={6}
                  className="w-full pl-10 pr-10 py-3 bg-[#111111] border border-white/15 focus:border-[#C6A15B] rounded-sm text-base font-mono tracking-widest text-[#F8F5EF] focus:outline-none transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                  aria-label="Toggle PIN visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Remember session */}
          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 text-xs text-white/70 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberSession}
                onChange={(e) => setRememberSession(e.target.checked)}
                className="rounded text-[#C6A15B] focus:ring-0 cursor-pointer"
              />
              <span>Remember session</span>
            </label>
            <button
              type="button"
              onClick={handleFillDefaults}
              className="text-[11px] text-[#C6A15B] hover:underline cursor-pointer"
            >
              Fill Default Credentials
            </button>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-4 py-3.5 px-4 bg-gradient-to-r from-[#D6B979] via-[#C6A15B] to-[#B38D43] text-[#111111] font-bold text-xs uppercase tracking-wider rounded-sm hover:brightness-110 active:scale-[0.99] disabled:opacity-50 transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Lock className="w-4 h-4" />
            <span>{isLoading ? 'Authenticating...' : 'Sign In to Owner Board'}</span>
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-white/10 text-center">
          <p className="text-[11px] text-white/40">
            Protected Salon Owner & Manager Administration
          </p>
        </div>
      </div>
    </div>
  );
};
