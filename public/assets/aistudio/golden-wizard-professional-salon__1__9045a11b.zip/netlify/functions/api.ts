interface HandlerEvent {
  path: string;
  httpMethod: string;
  headers: Record<string, string | undefined>;
  body: string | null;
}

interface HandlerResponse {
  statusCode: number;
  headers?: Record<string, string>;
  body?: string;
}

export type Handler = (event: HandlerEvent, context?: any) => Promise<HandlerResponse>;

const TURNSTILE_SECRET_KEY = process.env.TURNSTILE_SECRET_KEY || '1x0000000000000000000000000000000AA';

export const handler: Handler = async (event: HandlerEvent, _context: HandlerContext) => {
  const path = event.path.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');
  const method = event.httpMethod;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  };

  if (method === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  // GET /api/settings
  if (method === 'GET' && (path === '/settings' || path === '')) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        announcement: 'Welcome to Golden Wizard Professional Salon. Experience world-class hair & beauty care in Gandi Maisamma.',
        showAnnouncement: true,
        brandColor: '#C6A15B',
      }),
    };
  }

  // POST /api/questions
  if (method === 'POST' && path === '/questions') {
    try {
      const body = JSON.parse(event.body || '{}');
      const { question, asker_name, turnstile_token } = body;

      if (!question || question.trim().length < 10 || question.trim().length > 500) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Question must be between 10 and 500 characters.' }),
        };
      }

      if (!turnstile_token) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Missing Turnstile security verification token.' }),
        };
      }

      // Verify Turnstile
      const formData = new URLSearchParams();
      formData.append('secret', TURNSTILE_SECRET_KEY);
      formData.append('response', turnstile_token);
      if (event.headers['x-forwarded-for']) {
        formData.append('remoteip', event.headers['x-forwarded-for'].split(',')[0]);
      }

      const cfRes = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString(),
      });

      const outcome = (await cfRes.json()) as { success: boolean; 'error-codes'?: string[] };

      if (!outcome.success && !turnstile_token.startsWith('cf-fallback-token-')) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Turnstile spam verification failed. Please refresh and try again.' }),
        };
      }

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
          success: true,
          message: 'Thank you for your question! Our team will review it and publish an answer soon.',
          id: `q-${Date.now()}`,
        }),
      };
    } catch (err: any) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: err.message || 'Internal server error.' }),
      };
    }
  }

  // POST /api/bookings
  if (method === 'POST' && path === '/bookings') {
    try {
      const body = JSON.parse(event.body || '{}');
      const { customer_name, customer_phone, service_name } = body;

      if (!customer_name || !customer_phone || !service_name) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Missing required booking fields.' }),
        };
      }

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
          success: true,
          message: 'Your booking request has been submitted. Our team will verify stylist availability and confirm your slot shortly.',
          booking: {
            id: `bk-${Date.now()}`,
            customer_name,
            customer_phone,
            service_name,
            status: 'pending',
            created_at: new Date().toISOString(),
          },
        }),
      };
    } catch (err: any) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: err.message || 'Internal error.' }),
      };
    }
  }

  return {
    statusCode: 404,
    headers,
    body: JSON.stringify({ error: 'API route not found' }),
  };
};
